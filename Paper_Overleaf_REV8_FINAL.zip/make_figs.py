"""Generate the two core figures for the CQM scaling paper.
All numbers are hard-coded from the audited runs (3B/7B/14B/32B, MATH L1-5).
Outputs vector PDFs into the paper/ directory next to this file.
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
plt.rcParams.update({
    "font.size": 11, "axes.spines.top": False,
} if False else {"font.size": 11})

LEVELS = [1, 2, 3, 4, 5]
# false-consensus rate within converged, by official MATH Level
FC = {
    "Qwen2.5-3B":  [0.03, 0.21, 0.27, 0.35, 0.50],
    "Qwen2.5-7B":  [0.09, 0.21, 0.24, 0.39, 0.68],
    "Qwen2.5-14B": [0.08, 0.11, 0.14, 0.26, 0.62],
    "Qwen2.5-32B": [0.050, 0.086, 0.270, 0.333, 0.433],
}
MARK = {"Qwen2.5-3B": "o-", "Qwen2.5-7B": "s-", "Qwen2.5-14B": "^-", "Qwen2.5-32B": "D-"}

# ---- Figure 1: false-consensus rate vs official difficulty (monotone => strong non-circular control)
fig, ax = plt.subplots(figsize=(4.6, 3.3))
for m, ys in FC.items():
    ax.plot(LEVELS, ys, MARK[m], label=m, linewidth=1.8, markersize=6)
ax.set_xlabel("Official MATH difficulty Level")
ax.set_ylabel("False-consensus rate (converged)")
ax.set_xticks(LEVELS)
ax.set_ylim(0, 0.75)
ax.grid(True, alpha=0.3)
ax.legend(frameon=False, fontsize=9)
fig.tight_layout()
fig.savefig(os.path.join(HERE, "fig_dlevel.pdf"))
plt.close(fig)

# ---- Figure 2: four audited scale points (params on log x-axis)
PARAMS = [3, 7, 14, 32]
xlabels = ["3B", "7B", "14B", "32B"]
# within-Level AUC; official Level is a coarse control
r1a_wl = [0.774, 0.776, 0.724, 0.797]
mconf_wl = [0.512, 0.751, 0.694, 0.791]
# usable confidence gap (mean_conf TRUE - FALSE)
gap = [0.014, 0.049, 0.024, 0.057]

fig, (a1, a2) = plt.subplots(1, 2, figsize=(8.4, 3.3))
a1.plot(PARAMS, r1a_wl, "s-", color="#1f77b4", lw=2, ms=7, label="answer-agreement $r_1$")
a1.plot(PARAMS, mconf_wl, "o--", color="#d62728", lw=2, ms=7, label="confidence $\\bar{c}$")
a1.axhline(0.62, color="gray", ls=":", lw=1)
a1.text(3.1, 0.60, "survival 0.62", fontsize=8, color="gray")
a1.axhline(0.5, color="k", ls="-", lw=0.6, alpha=0.4)
a1.set_xscale("log"); a1.set_xticks(PARAMS); a1.set_xticklabels(xlabels)
a1.set_xlabel("Backbone size (params)")
a1.set_ylabel("Within-Level AUC")
a1.set_ylim(0.45, 0.85); a1.grid(True, alpha=0.3)
a1.legend(frameon=False, fontsize=9, loc="lower center")

a2.plot(PARAMS, gap, "o-", color="#d62728", lw=2, ms=8)
a2.set_xscale("log"); a2.set_xticks(PARAMS); a2.set_xticklabels(xlabels)
a2.set_xlabel("Backbone size (params)")
a2.set_ylabel("Usable confidence gap ($\\bar{c}_T-\\bar{c}_F$)")
a2.set_ylim(0, 0.06); a2.grid(True, alpha=0.3)
a2.annotate("14B dip", xy=(14, 0.024), xytext=(10, 0.010),
            fontsize=8, arrowprops=dict(arrowstyle="->", color="gray"))
fig.tight_layout()
fig.savefig(os.path.join(HERE, "fig_scaling.pdf"))
plt.close(fig)
print("figures written")
