"""Static sanity check for the LaTeX sources (no TeX engine available).
Checks: \\input targets exist, figures exist, \\cite keys are in the bib,
\\ref targets have a \\label, and \\begin/\\end environments balance.
"""
import os, re, glob
HERE = os.path.dirname(os.path.abspath(__file__))

def read(p):
    with open(os.path.join(HERE, p), encoding="utf-8") as f:
        return f.read()

# gather all tex we care about, following \input recursively (tables are
# \input from section files, not from main.tex, so a flat scan would miss them
# -- and a missed file silently skips its labels/braces from every check).
texts = {}


def collect(fn):
    fn = fn if fn.endswith(".tex") else fn + ".tex"
    if fn in texts:
        return
    assert os.path.exists(os.path.join(HERE, fn)), f"MISSING input: {fn}"
    t = read(fn)
    texts[fn] = t
    for name in re.findall(r"\\input\{([^}]+)\}", t):
        collect(name)


collect("main.tex")
print("inputs OK:", list(texts.keys()))

allsrc = "\n".join(texts.values())

# cite keys vs bib
bib = read("refs.bib")
bibkeys = set(re.findall(r"@\w+\{([^,]+),", bib))
cited = set()
for m in re.findall(r"\\cite[pt]?\{([^}]+)\}", allsrc):
    for k in m.split(","):
        cited.add(k.strip())
missing = cited - bibkeys
print("cite keys:", sorted(cited))
print("bib keys:", sorted(bibkeys))
assert not missing, f"CITED BUT NOT IN BIB: {missing}"
unused = bibkeys - cited
if unused:
    print("WARN unused bib entries:", sorted(unused))

# labels vs refs
labels = set(re.findall(r"\\label\{([^}]+)\}", allsrc))
refs = set(re.findall(r"\\ref\{([^}]+)\}", allsrc))
badref = refs - labels
assert not badref, f"REF WITHOUT LABEL: {badref}"
print("labels:", sorted(labels))

# figures
figs = re.findall(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}", allsrc)
for f in figs:
    fn = f if os.path.splitext(f)[1] else f + ".pdf"
    assert os.path.exists(os.path.join(HERE, fn)), f"MISSING FIGURE: {fn}"
print("figures OK:", figs)

# environment balance
begins = re.findall(r"\\begin\{([^}]+)\}", allsrc)
ends = re.findall(r"\\end\{([^}]+)\}", allsrc)
from collections import Counter
cb, ce = Counter(begins), Counter(ends)
for env in set(list(cb)+list(ce)):
    assert cb[env] == ce[env], f"ENV IMBALANCE {env}: {cb[env]} begin vs {ce[env]} end"
print("environments balanced:", dict(cb))

# brace balance per file
for name, t in texts.items():
    # strip comments
    lines = [re.sub(r"(?<!\\)%.*$", "", ln) for ln in t.splitlines()]
    s = "\n".join(lines)
    op = s.count("{") - s.count("\\{")
    cl = s.count("}") - s.count("\\}")
    assert op == cl, f"BRACE IMBALANCE in {name}: {op} open vs {cl} close"
print("braces balanced in all files")
print("\nALL STATIC CHECKS PASSED")

