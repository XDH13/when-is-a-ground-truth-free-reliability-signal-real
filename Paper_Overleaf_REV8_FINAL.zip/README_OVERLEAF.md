# Overleaf compilation notes

## Current package status

This directory is a generic pre-submission LaTeX package. A target venue and
its official style file have not yet been fixed; page-limit compliance therefore
cannot be claimed from this package alone.

The paper currently reports four Qwen2.5 scale points (3B, 7B, 14B, 32B),
single-scale Llama and Mistral stress tests, and MATH/ARC/MMLU domain tests.
The three figures are `fig_dlevel.pdf`, `fig_scaling.pdf`, and
`fig_conf_dist.pdf`.

## Compile on Overleaf

1. Upload the contents of this directory as one project.
2. Set `main.tex` as the main document.
3. Use pdfLaTeX and BibTeX.
4. Recompile from scratch if citations initially appear as `[?]`.

Equivalent local sequence:

```text
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Before submission, replace the generic `article` setup with the official venue
template, recompile, inspect every page visually, and check the current venue
rules for page limits, anonymity, ethics/reproducibility sections, and appendix
handling.

## Reproducibility note

`make_figs.py` regenerates the difficulty and scaling figures from the audited
summary values. `../confidence_saturation.py` regenerates the confidence
distribution figure from the four run logs. Static source checks are useful but
do not replace a successful LaTeX build and visual PDF inspection.
