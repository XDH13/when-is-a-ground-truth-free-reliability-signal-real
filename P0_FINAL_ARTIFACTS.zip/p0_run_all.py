"""Resumable orchestrator for the three P0 experiment families."""
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STATUS = ROOT / "P0_PIPELINE_STATUS.json"
FINAL = ROOT / "P0_COMPLETE.md"
START = time.time()


def update(step, state, **extra):
    payload = {
        "step": step,
        "state": state,
        "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_hours": round((time.time() - START) / 3600, 3),
        **extra,
    }
    tmp = STATUS.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(tmp, STATUS)
    print("STATUS", json.dumps(payload), flush=True)


def run(step, args, env=None):
    update(step, "RUNNING", command=args)
    merged = os.environ.copy()
    if env:
        merged.update(env)
    proc = subprocess.run([sys.executable, *args], cwd=ROOT, env=merged)
    if proc.returncode:
        update(step, "FAILED", returncode=proc.returncode)
        raise SystemExit(proc.returncode)
    update(step, "COMPLETE")


def main():
    update("initialise", "RUNNING", host=platform.node(), python=sys.version)
    run("build_disjoint_mmlu_pool", ["p0_build_mmlu_holdout.py"])
    # Complete the two previously partial non-Qwen MATH collections.  These
    # runs are both direct cross-family evidence and inputs to the independent
    # difficulty ensemble.  exp4_collect.py resumes by question text.
    run(
        "complete_math_llama8",
        ["exp4_collect.py"],
        {"EXP0_MODEL": "llama3.1:8b", "EXP4_LOG": "exp4_llama_log.jsonl", "EXP4_LIMIT": "240"},
    )
    run(
        "complete_math_mistral7",
        ["exp4_collect.py"],
        {"EXP0_MODEL": "mistral:7b-instruct", "EXP4_LOG": "exp4_mistral_log.jsonl", "EXP4_LIMIT": "240"},
    )
    run("multimodel_difficulty_crossfit", ["p0_multimodel_difficulty.py"])

    # Batch the new heterogeneous round-2 calls by physical model.  This order
    # minimizes Ollama model swaps while every stage remains independently resumable.
    hetero_tasks = [
        ("q3_l8_m7", 0), ("q7_l8_m7", 0), ("q14_l8_m7", 0),
        ("q3_l8_m7", 1), ("q7_l8_m7", 1), ("q14_l8_m7", 1),
        ("q3_l8_m7", 2), ("q7_l8_m7", 2), ("q14_l8_m7", 2),
    ]
    for config, slot in hetero_tasks:
        run(
            f"hetero_{config}_slot{slot}",
            ["p0_hetero_math.py", "--config", config, "--slot", str(slot), "--limit", "200"],
        )
    for config in ("q3_l8_m7", "q7_l8_m7", "q14_l8_m7"):
        run(
            f"hetero_{config}_assemble",
            ["p0_hetero_math.py", "--config", config, "--assemble", "--limit", "200"],
        )

    models = [
        ("qwen3", "qwen2.5:3b-instruct"),
        ("qwen7", "qwen2.5:7b-instruct"),
        ("llama8", "llama3.1:8b"),
        ("mistral7", "mistral:7b-instruct"),
        ("qwen14", "qwen2.5:14b-instruct"),
    ]
    for tag, model in models:
        run(
            f"mmlu_holdout_{tag}",
            ["p0_mcq_collect.py"],
            {
                "EXP0_MODEL": model,
                "P0_MCQ_POOL": "mmlu_holdout_pool.json",
                "P0_MCQ_LOG": f"p0_mmlu_holdout_{tag}.jsonl",
                "P0_MCQ_LIMIT": "200",
                "P0_DOMAIN": "mmlu-holdout",
                "P0_MCQ_SEED": "20260910",
            },
        )

    run("final_analysis", ["p0_analyze.py"])
    elapsed = (time.time() - START) / 3600
    report = [
        "# P0 experiment pipeline complete",
        "",
        f"- Completed: {time.strftime('%Y-%m-%d %H:%M:%S')}",
        f"- Elapsed hours in this invocation: {elapsed:.2f}",
        "- General-purpose models: Qwen2.5-3B/7B/14B, Llama-3.1-8B, Mistral-7B",
        "- External difficulty models: Llama-3.1-8B, Mistral-7B, Mathstral-7B",
        "- New heterogeneous MATH configurations: Qwen-{3,7,14}B + Llama-8B + Mistral-7B",
        "- New knowledge-domain pool: 200 MMLU holdout items, disjoint from the original pool",
        "",
        "See `P0_MULTIMODEL_DIFFICULTY.md` and `P0_EXPERIMENT_RESULTS.md` for results.",
        "Generation randomness is not backend-seeded; the fixed seed controls item order and analysis resampling only.",
    ]
    FINAL.write_text("\n".join(report) + "\n", encoding="utf-8")
    update("all", "COMPLETE", elapsed_hours=round(elapsed, 3))


if __name__ == "__main__":
    main()
