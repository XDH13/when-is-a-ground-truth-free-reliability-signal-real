# P0 experiment pipeline complete

- Completed: 2026-09-10 19:22:28
- Elapsed hours in this invocation: 0.28
- General-purpose models: Qwen2.5-3B/7B/14B, Llama-3.1-8B, Mistral-7B
- External difficulty models: Llama-3.1-8B, Mistral-7B, Mathstral-7B
- New heterogeneous MATH configurations: Qwen-{3,7,14}B + Llama-8B + Mistral-7B
- New knowledge-domain pool: 200 MMLU holdout items, disjoint from the original pool

See `P0_MULTIMODEL_DIFFICULTY.md` and `P0_EXPERIMENT_RESULTS.md` for results.
Generation randomness is not backend-seeded; the fixed seed controls item order and analysis resampling only.
