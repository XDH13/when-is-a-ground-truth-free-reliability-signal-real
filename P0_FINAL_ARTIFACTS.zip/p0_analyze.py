"""Analyze all P0 heterogeneous-agent and MMLU-holdout runs."""
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
SEED = 20260910
MATH = {
    "Qwen2.5-3B": "exp4_3b_log.jsonl",
    "Qwen2.5-7B": "exp4_multilevel_log.jsonl",
    "Qwen2.5-14B": "exp4_14b_log.jsonl",
    "Llama-3.1-8B": "exp4_llama_log.jsonl",
    "Mistral-7B": "exp4_mistral_log.jsonl",
}
MMLU = {
    "Qwen2.5-3B": "p0_mmlu_holdout_qwen3.jsonl",
    "Qwen2.5-7B": "p0_mmlu_holdout_qwen7.jsonl",
    "Qwen2.5-14B": "p0_mmlu_holdout_qwen14.jsonl",
    "Llama-3.1-8B": "p0_mmlu_holdout_llama8.jsonl",
    "Mistral-7B": "p0_mmlu_holdout_mistral7.jsonl",
}
HETERO = {
    "Qwen3+Llama8+Mistral7": "p0_hetero_math_q3_l8_m7.jsonl",
    "Qwen7+Llama8+Mistral7": "p0_hetero_math_q7_l8_m7.jsonl",
    "Qwen14+Llama8+Mistral7": "p0_hetero_math_q14_l8_m7.jsonl",
}
OUT_JSON = ROOT / "P0_EXPERIMENT_RESULTS.json"
OUT_MD = ROOT / "P0_EXPERIMENT_RESULTS.md"


def load(path):
    rows = []
    p = ROOT / path
    if not p.exists():
        return rows
    with p.open(encoding="utf-8") as fh:
        for line in fh:
            try:
                rec = json.loads(line)
                if not rec.get("invalid"):
                    rows.append(rec)
            except Exception:
                pass
    return rows


def cell_auc(true, false):
    if not true or not false:
        return np.nan
    t = np.asarray(true)[:, None]
    f = np.asarray(false)[None, :]
    return float(((t > f) + 0.5 * (t == f)).mean())


def strat_auc(rows):
    num = den = 0.0
    for level in sorted({int(r["level"]) for r in rows}):
        true = [r["features"]["r1_agree"] for r in rows if int(r["level"]) == level and r["correct"]]
        false = [r["features"]["r1_agree"] for r in rows if int(r["level"]) == level and not r["correct"]]
        if not true or not false:
            continue
        pairs = len(true) * len(false)
        num += cell_auc(true, false) * pairs
        den += pairs
    return float(num / den) if den else np.nan


def bootstrap(rows, draws=5000, seed=SEED):
    rng = np.random.default_rng(seed)
    levels = sorted({int(r["level"]) for r in rows})
    cells = {}
    for lv in levels:
        for correct in (False, True):
            cells[(lv, correct)] = [r for r in rows if int(r["level"]) == lv and bool(r["correct"]) == correct]
    vals = []
    for _ in range(draws):
        sample = []
        for cell in cells.values():
            if cell:
                sample.extend(cell[i] for i in rng.integers(0, len(cell), len(cell)))
        vals.append(strat_auc(sample))
    vals = np.asarray(vals)
    return vals


def summarize(rows, seed=SEED):
    converged = [r for r in rows if r.get("converged")]
    false = sum(not r.get("correct") for r in converged)
    if not converged or false == 0 or false == len(converged):
        return {"n_total": len(rows), "n_converged": len(converged), "n_false": false, "status": "UNTESTABLE"}
    dist = bootstrap(converged, seed=seed)
    point = strat_auc(converged)
    return {
        "n_total": len(rows),
        "n_converged": len(converged),
        "n_false": false,
        "false_rate": false / len(converged),
        "within_stratum_auc": point,
        "ci": [float(x) for x in np.quantile(dist, [0.025, 0.975])],
        "status": "OK" if false >= 15 else "UNDERPOWERED",
        "bootstrap": dist,
    }


def serializable(summary):
    return {k: v for k, v in summary.items() if k != "bootstrap"}


def main():
    results = {"seed": SEED, "heterogeneous_math": {}, "mmlu_holdout": {}, "domain_differences": {}}
    for i, (name, path) in enumerate(HETERO.items()):
        results["heterogeneous_math"][name] = serializable(summarize(load(path), SEED + i))
    math_summaries = {}
    for i, (name, path) in enumerate(MMLU.items()):
        mmlu = summarize(load(path), SEED + 100 + i)
        math = summarize(load(MATH[name]), SEED + 200 + i)
        results["mmlu_holdout"][name] = serializable(mmlu)
        math_summaries[name] = math
        if "bootstrap" in mmlu and "bootstrap" in math:
            n = min(len(mmlu["bootstrap"]), len(math["bootstrap"]))
            delta = math["bootstrap"][:n] - mmlu["bootstrap"][:n]
            results["domain_differences"][name] = {
                "math_minus_mmlu_auc": math["within_stratum_auc"] - mmlu["within_stratum_auc"],
                "ci": [float(x) for x in np.quantile(delta, [0.025, 0.975])],
                "bootstrap_probability_math_greater": float(np.mean(delta > 0)),
                "note": "independent stratified bootstrap; disjoint domain pools",
            }
    OUT_JSON.write_text(json.dumps(results, indent=2), encoding="utf-8")
    lines = [
        "# P0 experiment results",
        "",
        "## Heterogeneous agents on MATH",
        "",
        "Round 1 reuses fixed draws from matched homogeneous runs; round 2 is newly generated after cross-family answer exchange.",
        "",
        "| configuration | total | converged / false | within-Level agreement AUC | status |",
        "|---|---:|---:|---:|---|",
    ]
    for name, r in results["heterogeneous_math"].items():
        auc = f"{r['within_stratum_auc']:.3f} [{r['ci'][0]:.3f},{r['ci'][1]:.3f}]" if "ci" in r else "NA"
        lines.append(f"| {name} | {r['n_total']} | {r['n_converged']} / {r['n_false']} | {auc} | {r['status']} |")
    lines += [
        "",
        "## Disjoint MMLU holdout",
        "",
        "The pool is disjoint from the original 150-item MMLU pool and uses a generic MCQ prompt shared by all five models.",
        "",
        "| model | total | converged / false | within-tier agreement AUC | status | MATH minus MMLU |",
        "|---|---:|---:|---:|---|---:|",
    ]
    for name, r in results["mmlu_holdout"].items():
        auc = f"{r['within_stratum_auc']:.3f} [{r['ci'][0]:.3f},{r['ci'][1]:.3f}]" if "ci" in r else "NA"
        d = results["domain_differences"].get(name)
        ds = f"{d['math_minus_mmlu_auc']:+.3f} [{d['ci'][0]:+.3f},{d['ci'][1]:+.3f}]" if d else "NA"
        lines.append(f"| {name} | {r['n_total']} | {r['n_converged']} / {r['n_false']} | {auc} | {r['status']} | {ds} |")
    lines += [
        "",
        "All intervals are item-level stratified bootstrap intervals. A cell with fewer than 15 false-consensus cases is labelled UNDERPOWERED and is not interpreted.",
    ]
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(OUT_MD.read_text(encoding="utf-8"), flush=True)


if __name__ == "__main__":
    main()
