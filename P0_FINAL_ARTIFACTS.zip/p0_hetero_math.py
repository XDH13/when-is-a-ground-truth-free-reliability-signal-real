"""Heterogeneous-agent MATH experiment using fixed, pre-existing round-1 draws.

Each configuration uses one Qwen draw plus one Llama and one Mistral draw from
the matched homogeneous runs.  Selection is mechanical: raw index 0, falling
forward to the first parseable answer only when index 0 is missing.  Round 2 is
newly generated for each agent after seeing the other families' round-1
answers.  Stages are batched by model and resumable to avoid model thrashing.
"""
import argparse
import json
import os
from collections import Counter
from pathlib import Path

import exp0_math as E

ROOT = Path(__file__).resolve().parent
CONFIGS = {
    "q3_l8_m7": [
        ("qwen2.5:3b-instruct", "exp4_3b_log.jsonl"),
        ("llama3.1:8b", "exp4_llama_log.jsonl"),
        ("mistral:7b-instruct", "exp4_mistral_log.jsonl"),
    ],
    "q7_l8_m7": [
        ("qwen2.5:7b-instruct", "exp4_multilevel_log.jsonl"),
        ("llama3.1:8b", "exp4_llama_log.jsonl"),
        ("mistral:7b-instruct", "exp4_mistral_log.jsonl"),
    ],
    "q14_l8_m7": [
        ("qwen2.5:14b-instruct", "exp4_14b_log.jsonl"),
        ("llama3.1:8b", "exp4_llama_log.jsonl"),
        ("mistral:7b-instruct", "exp4_mistral_log.jsonl"),
    ],
}


def load(path):
    out = {}
    with (ROOT / path).open(encoding="utf-8") as fh:
        for line in fh:
            try:
                rec = json.loads(line)
                if not rec.get("invalid"):
                    out[rec["q"]] = rec
            except Exception:
                pass
    return out


def chosen_r1(rec):
    answers = rec.get("raw", {}).get("r1_ans", [])
    confs = rec.get("raw", {}).get("r1_conf", [])
    order = list(range(len(answers)))
    for idx in order:
        if answers[idx] is not None:
            conf = confs[idx] if idx < len(confs) else 0.5
            try:
                conf = min(1.0, max(0.0, float(conf)))
            except Exception:
                conf = 0.5
            return float(answers[idx]), conf, idx
    return None, 0.5, None


def stage_path(config, slot):
    return ROOT / f"p0_hetero_{config}_slot{slot}.jsonl"


def final_path(config):
    return ROOT / f"p0_hetero_math_{config}.jsonl"


def run_stage(config, slot, limit):
    specs = CONFIGS[config]
    maps = [load(path) for _, path in specs]
    common = sorted(set.intersection(*(set(m) for m in maps)))
    common.sort(key=lambda q: (maps[0][q].get("level", 0), q))
    model = specs[slot][0]
    E.MODEL = model
    out = stage_path(config, slot)
    done = set()
    if out.exists():
        for line in out.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
                if not rec.get("invalid"):
                    done.add(rec["q"])
            except Exception:
                pass
    print(
        f"hetero stage config={config} slot={slot} model={model} "
        f"eligible={len(common)} resume={len(done)}",
        flush=True,
    )
    completed = len(done)
    with out.open("a", encoding="utf-8") as fh:
        for q in common:
            if completed >= limit:
                break
            if q in done:
                continue
            selected = [chosen_r1(m[q]) for m in maps]
            if any(ans is None for ans, _, _ in selected):
                rec = {"q": q, "invalid": True, "reason": "a family has no parseable r1 answer"}
            else:
                mine = selected[slot][0]
                others = [selected[j][0] for j in range(3) if j != slot]
                text, finish = E.call(E.REVISE.format(q=q, mine=mine, others=others))
                parsed = E.parse_json(text)
                if finish != "STOP":
                    rec = {"q": q, "invalid": True, "reason": f"finish={finish}"}
                else:
                    answer = E.num(parsed.get("answer")) if parsed else mine
                    try:
                        conf = float(parsed.get("confidence", selected[slot][1])) if parsed else selected[slot][1]
                    except Exception:
                        conf = selected[slot][1]
                    reasoning = parsed.get("reasoning", "") if parsed else ""
                    rec = {
                        "q": q,
                        "model": model,
                        "slot": slot,
                        "r1_answer": mine,
                        "r1_conf": selected[slot][1],
                        "r1_source_index": selected[slot][2],
                        "other_r1_answers": others,
                        "r2_answer": answer,
                        "r2_conf": min(1.0, max(0.0, conf)),
                        "r2_reasoning": reasoning,
                        "parsed": parsed is not None,
                    }
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            completed += 1
            print(f"{completed}/{min(limit, len(common))} invalid={rec.get('invalid', False)}", flush=True)


def agree(values):
    valid = [v for v in values if v is not None]
    if not valid:
        return 0.0, None
    top, count = Counter(valid).most_common(1)[0]
    return count / 3, top


def assemble(config, limit):
    specs = CONFIGS[config]
    bases = [load(path) for _, path in specs]
    stages = [load(stage_path(config, i).name) for i in range(3)]
    common = set.intersection(*(set(m) for m in bases), *(set(m) for m in stages))
    ordered = sorted(common, key=lambda q: (bases[0][q].get("level", 0), q))[:limit]
    out_rows = []
    for q in ordered:
        if any(stages[i][q].get("invalid") for i in range(3)):
            continue
        selected = [chosen_r1(bases[i][q]) for i in range(3)]
        r1a = [x[0] for x in selected]
        r1c = [x[1] for x in selected]
        r2a = [stages[i][q].get("r2_answer") for i in range(3)]
        r2c = [stages[i][q].get("r2_conf", 0.5) for i in range(3)]
        r2r = [stages[i][q].get("r2_reasoning", "") for i in range(3)]
        r1_agree, _ = agree(r1a)
        r2_agree, majority = agree(r2a)
        base = bases[0][q]
        gold = float(base["gold"])
        mc = sum(r2c) / 3
        out_rows.append({
            "q": q,
            "gold": gold,
            "level": int(base["level"]),
            "tier": base.get("tier", f"math-level{base['level']}"),
            "models": [m for m, _ in specs],
            "majority": majority,
            "converged": r2_agree >= 2 / 3,
            "correct": majority is not None and abs(majority - gold) < 1e-4,
            "features": {
                "r1_agree": r1_agree,
                "r2_agree": r2_agree,
                "agree_slope": r2_agree - r1_agree,
                "r2_div": E.divergence(r2r),
                "mean_conf": mc,
                "conf_var": sum((c - mc) ** 2 for c in r2c) / 3,
            },
            "difficulty": {
                "hetero_solo_wrong_frac": sum(a is None or abs(a - gold) >= 1e-4 for a in r1a) / 3,
            },
            "raw": {
                "r1_ans": r1a,
                "r1_conf": r1c,
                "r1_source_index": [x[2] for x in selected],
                "r2_ans": r2a,
                "r2_conf": r2c,
            },
            "protocol": {
                "r1_reused_from_matched_homogeneous_runs": True,
                "r1_selection": "index 0, first parseable fallback",
                "r2_new": True,
                "temperature": 0.7,
                "num_predict": 1536,
            },
        })
    tmp = final_path(config).with_suffix(".jsonl.tmp")
    tmp.write_text("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in out_rows), encoding="utf-8")
    os.replace(tmp, final_path(config))
    print(f"assembled {len(out_rows)} -> {final_path(config).name}", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", choices=CONFIGS, required=True)
    parser.add_argument("--slot", type=int, choices=(0, 1, 2))
    parser.add_argument("--assemble", action="store_true")
    parser.add_argument("--limit", type=int, default=200)
    args = parser.parse_args()
    if args.assemble:
        assemble(args.config, args.limit)
    elif args.slot is not None:
        run_stage(args.config, args.slot, args.limit)
    else:
        parser.error("provide --slot or --assemble")


if __name__ == "__main__":
    main()
