# P0 multi-model difficulty and nonlinear cross-fitting

Controls use official Level plus Llama-8B, Mistral-7B, and Mathstral-7B error signals; no Qwen answer enters the ensemble.
This is a robustness analysis, not causal identification.

| target | n / false | raw within-Level AUC | nonlinear cross-fit residual AUC | control OOF AUC | full OOF AUC | delta log loss |
|---|---:|---:|---:|---:|---:|---:|
| Qwen2.5-3B | 123 / 29 | 0.776 [0.691,0.855] | 0.711 [0.605,0.803] | 0.805 | 0.852 | -0.0379 |
| Qwen2.5-7B | 188 / 56 | 0.778 [0.703,0.850] | 0.691 [0.590,0.793] | 0.861 | 0.881 | -0.0275 |
| Qwen2.5-14B | 174 / 39 | 0.722 [0.632,0.809] | 0.649 [0.523,0.764] | 0.845 | 0.864 | -0.0153 |
