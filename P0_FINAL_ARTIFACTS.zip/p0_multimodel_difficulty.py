"""P0: multi-model difficulty ensemble and nonlinear cross-fitted robustness.

The Qwen outcome runs are controlled only with signals from other model
families: Llama-3.1-8B, Mistral-7B, Mathstral-7B, plus official MATH Level.
No Qwen answer enters the difficulty ensemble.  Tree models are cross-fitted so
that each item's nuisance prediction is produced by a model not trained on that
item.  This is a robustness analysis, not causal identification.
"""
import json
from pathlib import Path

import numpy as np
from sklearn.ensemble import ExtraTreesRegressor, RandomForestClassifier
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold

ROOT = Path(__file__).resolve().parent
TARGETS = {
    "Qwen2.5-3B": "exp4_3b_log.jsonl",
    "Qwen2.5-7B": "exp4_multilevel_log.jsonl",
    "Qwen2.5-14B": "exp4_14b_log.jsonl",
}
INDEPENDENT = {
    "llama": "exp4_llama_log.jsonl",
    "mistral": "exp4_mistral_log.jsonl",
}
EXT = "exp4_extdiff_log.jsonl"
OUT_JSON = ROOT / "P0_MULTIMODEL_DIFFICULTY.json"
OUT_MD = ROOT / "P0_MULTIMODEL_DIFFICULTY.md"
SEED = 20260910


def load(path):
    out = {}
    with (ROOT / path).open(encoding="utf-8") as fh:
        for line in fh:
            try:
                rec = json.loads(line)
                if not rec.get("invalid"):
                    out[rec["q"]] = rec
            except Exception:
                pass
    return out


def wrong_fraction(rec):
    gold = float(rec["gold"])
    ans = rec.get("raw", {}).get("r1_ans", [])
    if not ans:
        return np.nan
    return float(np.mean([a is None or abs(float(a) - gold) >= 1e-4 for a in ans]))


def strat_auc(y, score, level):
    num = den = 0.0
    for lv in sorted(set(level)):
        t = score[(level == lv) & (y == 0)]
        f = score[(level == lv) & (y == 1)]
        if not len(t) or not len(f):
            continue
        # Orient larger score toward true consensus, matching agreement.
        wins = sum((t[:, None] > f[None, :]).ravel())
        ties = sum((t[:, None] == f[None, :]).ravel())
        pairs = len(t) * len(f)
        num += wins + 0.5 * ties
        den += pairs
    return float(num / den) if den else float("nan")


def bootstrap_strat_auc(y, score, level, draws=3000):
    rng = np.random.default_rng(SEED)
    vals = []
    levels = sorted(set(level))
    for _ in range(draws):
        ids = []
        for lv in levels:
            for cls in (0, 1):
                cell = np.flatnonzero((level == lv) & (y == cls))
                if len(cell):
                    ids.extend(rng.choice(cell, size=len(cell), replace=True))
        ids = np.asarray(ids, dtype=int)
        vals.append(strat_auc(y[ids], score[ids], level[ids]))
    return [float(x) for x in np.quantile(vals, [0.025, 0.975])]


def crossfit_signal_residual(X, signal, y):
    # Average ten independent five-fold cross-fits for a stable nuisance estimate.
    splitter = RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=SEED)
    pred_sum = np.zeros(len(y))
    pred_n = np.zeros(len(y))
    for fold, (train, test) in enumerate(splitter.split(X, y)):
        reg = ExtraTreesRegressor(
            n_estimators=250,
            max_depth=4,
            min_samples_leaf=8,
            max_features=1.0,
            random_state=SEED + fold,
            n_jobs=-1,
        )
        reg.fit(X[train], signal[train])
        pred_sum[test] += reg.predict(X[test])
        pred_n[test] += 1
    return signal - pred_sum / pred_n


def crossfit_incremental(X, signal, y):
    splitter = RepeatedStratifiedKFold(n_splits=5, n_repeats=10, random_state=SEED + 1)
    base_sum = np.zeros(len(y))
    full_sum = np.zeros(len(y))
    pred_n = np.zeros(len(y))
    for fold, (train, test) in enumerate(splitter.split(X, y)):
        kwargs = dict(
            n_estimators=350,
            max_depth=4,
            min_samples_leaf=8,
            class_weight="balanced_subsample",
            random_state=SEED + fold,
            n_jobs=-1,
        )
        base = RandomForestClassifier(**kwargs)
        full = RandomForestClassifier(**{**kwargs, "random_state": SEED + 1000 + fold})
        base.fit(X[train], y[train])
        full.fit(np.column_stack([X[train], signal[train]]), y[train])
        base_sum[test] += base.predict_proba(X[test])[:, 1]
        full_sum[test] += full.predict_proba(np.column_stack([X[test], signal[test]]))[:, 1]
        pred_n[test] += 1
    pb = np.clip(base_sum / pred_n, 1e-5, 1 - 1e-5)
    pf = np.clip(full_sum / pred_n, 1e-5, 1 - 1e-5)
    return {
        "control_oof_auc": float(roc_auc_score(y, pb)),
        "full_oof_auc": float(roc_auc_score(y, pf)),
        "delta_oof_auc": float(roc_auc_score(y, pf) - roc_auc_score(y, pb)),
        "control_logloss": float(log_loss(y, pb)),
        "full_logloss": float(log_loss(y, pf)),
        "delta_logloss_full_minus_control": float(log_loss(y, pf) - log_loss(y, pb)),
    }


def analyze(name, target, llama, mistral, ext):
    common = set(target) & set(llama) & set(mistral) & set(ext)
    rows = [target[q] for q in common if target[q].get("converged")]
    rows.sort(key=lambda r: (int(r["level"]), r["q"]))
    q = [r["q"] for r in rows]
    y = np.asarray([0 if r["correct"] else 1 for r in rows], dtype=int)
    level = np.asarray([int(r["level"]) for r in rows], dtype=int)
    signal = np.asarray([float(r["features"]["r1_agree"]) for r in rows])
    d_llama = np.asarray([wrong_fraction(llama[x]) for x in q])
    d_mistral = np.asarray([wrong_fraction(mistral[x]) for x in q])
    d_mathstral = np.asarray([float(ext[x]["ext_wrong_frac"]) for x in q])
    X = np.column_stack([level, d_llama, d_mistral, d_mathstral])
    if np.isnan(X).any():
        raise RuntimeError(f"missing independent difficulty values for {name}")
    d_ensemble = np.mean(X[:, 1:], axis=1)
    residual = crossfit_signal_residual(X, signal, y)
    raw_auc = strat_auc(y, signal, level)
    residual_auc = strat_auc(y, residual, level)
    bins = []
    for lo, hi in ((-0.01, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.01)):
        mask = (d_ensemble > lo) & (d_ensemble <= hi)
        if mask.any():
            bins.append({
                "range": [lo, hi],
                "n": int(mask.sum()),
                "false_consensus_rate": float(y[mask].mean()),
            })
    return {
        "n_converged": len(rows),
        "n_false": int(y.sum()),
        "controls": ["official_level", "llama_r1_error", "mistral_r1_error", "mathstral_error"],
        "ensemble_excludes_qwen": True,
        "raw_within_level_auc": raw_auc,
        "raw_ci": bootstrap_strat_auc(y, signal, level),
        "crossfit_nonlinear_residual_within_level_auc": residual_auc,
        "residual_ci": bootstrap_strat_auc(y, residual, level),
        "incremental_oof": crossfit_incremental(X, signal, y),
        "ensemble_bins": bins,
    }


def main():
    llama = load(INDEPENDENT["llama"])
    mistral = load(INDEPENDENT["mistral"])
    ext = load(EXT)
    results = {
        "design": "other-family ensemble plus official Level; repeated 5-fold cross-fitting",
        "seed": SEED,
        "warning": "robustness analysis, not causal identification",
        "models": {},
    }
    for name, path in TARGETS.items():
        results["models"][name] = analyze(name, load(path), llama, mistral, ext)
        print(name, json.dumps(results["models"][name], indent=2), flush=True)
    OUT_JSON.write_text(json.dumps(results, indent=2), encoding="utf-8")
    lines = [
        "# P0 multi-model difficulty and nonlinear cross-fitting",
        "",
        "Controls use official Level plus Llama-8B, Mistral-7B, and Mathstral-7B error signals; no Qwen answer enters the ensemble.",
        "This is a robustness analysis, not causal identification.",
        "",
        "| target | n / false | raw within-Level AUC | nonlinear cross-fit residual AUC | control OOF AUC | full OOF AUC | delta log loss |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for name, r in results["models"].items():
        inc = r["incremental_oof"]
        lines.append(
            f"| {name} | {r['n_converged']} / {r['n_false']} | {r['raw_within_level_auc']:.3f} "
            f"[{r['raw_ci'][0]:.3f},{r['raw_ci'][1]:.3f}] | "
            f"{r['crossfit_nonlinear_residual_within_level_auc']:.3f} "
            f"[{r['residual_ci'][0]:.3f},{r['residual_ci'][1]:.3f}] | "
            f"{inc['control_oof_auc']:.3f} | {inc['full_oof_auc']:.3f} | "
            f"{inc['delta_logloss_full_minus_control']:+.4f} |"
        )
    OUT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"saved {OUT_JSON.name} and {OUT_MD.name}", flush=True)


if __name__ == "__main__":
    main()
