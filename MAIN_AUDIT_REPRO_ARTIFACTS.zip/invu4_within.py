"""Stratified (within-Level) counterpart of invu4_significance.py.

WHY THIS EXISTS (round-2 review, finding A). invu4_significance.py pools all
converged items and ignores Level, so Table tab:invu reports POOLED confidence
AUCs (0.588/0.774/0.758/0.837), while tab:main reports WITHIN-LEVEL ones
(0.512/0.751/0.694/0.791) and fig:scaling captions its left panel as
"within-stratum". The reviewer's objection is fair: the paper's central claim
about confidence ("the 14B dip is not detectable on the rank-invariant AUC or
variance-standardised gap") was tested on
the pooled estimand only, and the within-Level estimand never received a
corresponding between-scale test. This script supplies it.

ESTIMANDS. For each scale we compute all three measures under Level
stratification, so difficulty is held fixed by construction:

  * stratified AUC   -- within each Level, every (true, false) pair is scored;
                        the estimate is the pair-weighted concordance over all
                        Levels. DIRECTIONAL: P(conf_true > conf_false). We do
                        NOT fold with max(c, 1-c) the way _scaling4pt.py does,
                        because folding puts a hard floor at 0.5 and would bias
                        every bootstrap difference upward near chance (3B sits
                        exactly there). We print the folded value alongside for
                        comparison with tab:main, but all tests use the
                        directional one.
  * stratified gap   -- per-Level mean(true) - mean(false), pair-weighted across
                        Levels to match the AUC weighting.
  * stratified logit gap -- same, on logit means.

BOOTSTRAP. Items are resampled WITHIN each Level (stratified bootstrap),
separately for the true and false groups, so the Level composition is held
fixed. Scales are resampled independently because their converged item sets
differ; the arms are therefore between-scale contrasts, not paired.

This script answers one question: does the paper's confidence story survive when
the estimand matches the one the tables and figure captions advertise?
"""
import bisect
import collections
import json
import math
import os
import random

LOGS = [
    ("3B",  "exp4_3b_bl.jsonl"),
    ("7B",  "exp4_multilevel_log.jsonl"),
    ("14B", "exp4_14b_log.jsonl"),
    ("32B", "exp4_32b_log.jsonl"),
]
ORDER = ["3B", "7B", "14B", "32B"]
B = 20000
SEED = 20260909


def logit(p, eps=1e-6):
    p = min(max(p, eps), 1 - eps)
    return math.log(p / (1 - p))


def load(path):
    """Return {level: (true_confs, false_confs)} for converged items."""
    by = collections.defaultdict(lambda: ([], []))
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            if r.get("invalid") or not r.get("converged"):
                continue
            lv = r.get("level")
            c = r["features"].get("mean_conf")
            if lv is None or c is None:
                continue
            tc, fc = by[lv]
            (tc if r.get("correct") else fc).append(float(c))
    return dict(by)


def mean(xs):
    return sum(xs) / len(xs)


def _pair_concordance(pos, neg):
    """(sum of concordance, n_pairs) for one stratum. pos = true consensus."""
    if not pos or not neg:
        return 0.0, 0
    ns = sorted(neg)
    s = 0.0
    for a in pos:
        lo = bisect.bisect_left(ns, a)
        hi = bisect.bisect_right(ns, a)
        s += lo + 0.5 * (hi - lo)
    return s, len(pos) * len(neg)


def strat_auc(strata):
    """Directional pair-weighted within-Level AUC: P(conf_true > conf_false)."""
    num = den = 0.0
    for tc, fc in strata.values():
        s, n = _pair_concordance(tc, fc)
        num += s
        den += n
    return num / den if den else float("nan")


def strat_gap(strata, transform=None):
    """Pair-weighted within-Level mean gap (optionally on transformed means)."""
    num = den = 0.0
    for tc, fc in strata.values():
        if not tc or not fc:
            continue
        n = len(tc) * len(fc)
        mt, mf = mean(tc), mean(fc)
        if transform:
            mt, mf = transform(mt), transform(mf)
        num += (mt - mf) * n
        den += n
    return num / den if den else float("nan")


def strat_gap_prob(strata):
    return strat_gap(strata)


def strat_gap_logit(strata):
    return strat_gap(strata, transform=logit)


def ci(vals, a=0.025):
    v = sorted(vals)
    return v[int(a * len(v))], v[int((1 - a) * len(v)) - 1]


def main():
    data = {}
    for scale, path in LOGS:
        if not os.path.exists(path):
            print("MISSING", path)
            return
        data[scale] = load(path)

    print("=" * 74)
    print("WITHIN-LEVEL (stratified) four-point audit of confidence")
    print("=" * 74)
    print("\n=== per-Level counts (true/false), and usable pairs ===")
    for s in ORDER:
        strata = data[s]
        cells = []
        pairs = 0
        for lv in sorted(strata):
            tc, fc = strata[lv]
            pairs += len(tc) * len(fc)
            cells.append(f"L{lv}:{len(tc)}/{len(fc)}")
        print(f"  {s:<4} {' '.join(cells)}   pairs={pairs}")
    print("\n  NOTE: strata with an empty class contribute no pairs and drop out.")

    rnd = random.Random(SEED)

    def resample(strata):
        """Stratified bootstrap: resample items within each Level and class."""
        out = {}
        for lv, (tc, fc) in strata.items():
            bt = [tc[rnd.randrange(len(tc))] for _ in range(len(tc))] if tc else []
            bf = [fc[rnd.randrange(len(fc))] for _ in range(len(fc))] if fc else []
            out[lv] = (bt, bf)
        return out

    for name, stat in [("probability-scale gap (within-Level)", strat_gap_prob),
                       ("logit-scale gap (within-Level)", strat_gap_logit),
                       ("AUC (within-Level, directional)", strat_auc)]:
        print(f"\n{'=' * 74}\n=== {name} ===")
        point = {s: stat(data[s]) for s in ORDER}
        draws = {s: [] for s in ORDER}
        for _ in range(B):
            for s in ORDER:
                draws[s].append(stat(resample(data[s])))

        for s in ORDER:
            lo, hi = ci(draws[s])
            extra = ""
            if stat is strat_auc:
                extra = f"   [folded |AUC| = {max(point[s], 1 - point[s]):.3f}]"
            print(f"  {s:<4} {point[s]:+.4f}  95% CI [{lo:+.4f}, {hi:+.4f}]{extra}")

        print("  --- consecutive arms ---")
        for a, b in zip(ORDER, ORDER[1:]):
            d = [draws[b][i] - draws[a][i] for i in range(B)]
            lo, hi = ci(d)
            pu = sum(1 for x in d if x > 0) / B
            sig = "SIGNIF up" if lo > 0 else ("SIGNIF down" if hi < 0 else "n.s.")
            print(f"    {a:>3}->{b:<4} {point[b]-point[a]:+.4f} "
                  f"CI [{lo:+.4f}, {hi:+.4f}] P(up)={pu:.3f}  {sig}")

        p_dip = sum(1 for i in range(B)
                    if draws["14B"][i] < draws["7B"][i]
                    and draws["14B"][i] < draws["32B"][i]) / B
        p_peak7 = sum(1 for i in range(B)
                      if draws["7B"][i] > draws["3B"][i]
                      and draws["7B"][i] > draws["14B"][i]
                      and draws["7B"][i] > draws["32B"][i]) / B
        p_mono = sum(1 for i in range(B)
                     if draws["3B"][i] <= draws["7B"][i] <= draws["32B"][i]) / B
        p_max32 = sum(1 for i in range(B)
                      if draws["32B"][i] >= max(draws[s][i] for s in ORDER)) / B
        print("  --- shape hypotheses ---")
        print(f"    P(14B is a local dip: 7B>14B<32B) = {p_dip:.3f}")
        print(f"    P(7B is the global interior peak) = {p_peak7:.3f}")
        print(f"    P(3B<=7B<=32B, i.e. no 7B peak)   = {p_mono:.3f}")
        print(f"    P(32B is the maximum)             = {p_max32:.3f}")

    print(f"\n{'=' * 74}")
    print("WHAT TO CHECK AGAINST THE POOLED RUN (invu4_significance.py)")
    print("=" * 74)
    print("The paper's confidence claim is that the 7B->14B dip is significant on")
    print("the bounded probability scale but NOT detectable on the rank-invariant")
    print("AUC or variance-standardised gap.")
    print("If that pattern also holds here, the claim is estimand-robust and the")
    print("tables merely need consistent labelling. If it FLIPS -- e.g. the dip")
    print("becomes significant on the within-Level AUC, or the probability-scale")
    print("dip stops being significant -- then the pooled result was carrying the")
    print("claim and the text must be rewritten, not relabelled.")


if __name__ == "__main__":
    main()
