"""Threshold sensitivity for the 0.62 survival gate (reviewer objection C5:
"the 0.62 survival threshold has no stated justification / appears post hoc").

The honest defence is not to argue for 0.62 but to show the QUALITATIVE verdict
is invariant over a range of thresholds containing it. We compute, from the
-Dstr-lvl (Gate 4) column that the paper actually reports, the largest interval
of thresholds tau over which BOTH of the paper's claims hold:

    (i)  answer-agreement survives at every scale/family
    (ii) confidence fails at 3B, 14B, Llama, Mistral

If that interval is empty or excludes 0.62, the reviewer is right and the
threshold is doing the work. If 0.62 sits inside it, the choice is immaterial.

Values are the -Dstr+lvl column printed by exp4_audit.py on each log.
"""

# signal -> {run: AUC after removing structural proxies + official Level}
GATE4 = {
    "r1_agree":  {"3B": 0.696, "7B": 0.691, "14B": 0.642, "32B": 0.774,
                  "Llama-8B": 0.695, "Mistral-7B": 0.691},
    "r2_agree":  {"3B": 0.692, "7B": 0.635, "14B": 0.722, "32B": 0.677,
                  "Llama-8B": 0.650, "Mistral-7B": 0.663},
    "mean_conf": {"3B": 0.511, "7B": 0.642, "14B": 0.595, "32B": 0.724,
                  "Llama-8B": 0.545, "Mistral-7B": 0.508},
}

# Which runs must show confidence FAILING for the paper's story to hold.
CONF_MUST_FAIL = ["3B", "14B", "Llama-8B", "Mistral-7B"]
CONF_MUST_PASS = ["7B", "32B"]
PAPER_TAU = 0.62


def main():
    agree = GATE4["r1_agree"]
    conf = GATE4["mean_conf"]

    # (i) agreement survives everywhere  <=>  tau <= min(agreement)
    tau_hi_agree = min(agree.values())
    arg_hi = min(agree, key=agree.get)

    # (ii) confidence fails where it must  <=>  tau > max(conf on those runs)
    tau_lo_conf = max(conf[r] for r in CONF_MUST_FAIL)
    arg_lo = max(CONF_MUST_FAIL, key=lambda r: conf[r])

    # (iii) confidence passes where the paper says it does <=> tau <= min of those
    tau_hi_conf = min(conf[r] for r in CONF_MUST_PASS)
    arg_hi_c = min(CONF_MUST_PASS, key=lambda r: conf[r])

    lo = tau_lo_conf
    hi = min(tau_hi_agree, tau_hi_conf)

    print("=" * 72)
    print("Threshold sensitivity of the qualitative verdict (Gate 4 column)")
    print("=" * 72)
    print(f"  agreement survives everywhere requires tau <= {tau_hi_agree:.3f}"
          f"   (binding run: {arg_hi})")
    print(f"  confidence fails where claimed requires  tau >  {tau_lo_conf:.3f}"
          f"   (binding run: {arg_lo})")
    print(f"  confidence passes where claimed requires tau <= {tau_hi_conf:.3f}"
          f"   (binding run: {arg_hi_c})")
    print()
    if lo < hi:
        print(f"  INVARIANCE WINDOW: tau in ({lo:.3f}, {hi:.3f}]")
        print(f"  width = {hi - lo:.3f}")
        inside = lo < PAPER_TAU <= hi
        print(f"  paper's tau = {PAPER_TAU} is inside: {inside}")
        if inside:
            print(f"  margin below = {PAPER_TAU - lo:+.3f}, "
                  f"margin above = {hi - PAPER_TAU:+.3f}")
    else:
        print("  NO invariance window: the verdict depends on the threshold.")
        print("  -> reviewer is right; the threshold is doing the work.")

    print()
    print("=" * 72)
    print("Per-threshold verdict table")
    print("=" * 72)
    runs = ["3B", "7B", "14B", "32B", "Llama-8B", "Mistral-7B"]
    print("  tau   | " + " ".join(f"{r:>10}" for r in runs))
    print("        | " + " ".join(f"{'agr/conf':>10}" for _ in runs))
    print("  " + "-" * 78)
    for tau in [0.55, 0.58, 0.60, 0.62, 0.64, 0.66, 0.70]:
        cells = []
        for r in runs:
            a = "P" if agree[r] >= tau else "F"
            c = "P" if conf[r] >= tau else "F"
            cells.append(f"{a + '/' + c:>10}")
        mark = "  <-- paper" if abs(tau - PAPER_TAU) < 1e-9 else ""
        print(f"  {tau:.2f}  | " + " ".join(cells) + mark)

    print()
    print("Reading: the agreement row is P at every run for tau <= "
          f"{tau_hi_agree:.3f}; the confidence pattern (F at 3B/14B/Llama/"
          f"Mistral, P at 7B/32B) holds for tau in ({lo:.3f}, {hi:.3f}].")


if __name__ == "__main__":
    main()