"""Operational threshold performance for confidence, replacing the mean gap.

Reviewer objection: "A smaller mean gap does not uniquely imply worse threshold
performance. Report a prespecified thresholding metric -- e.g. sensitivity at a
fixed false-escalation rate, with the threshold selected on a training split and
evaluated on a held-out split. Otherwise 'thresholdable' is being equated with
'mean-separated', which is not justified."

That is exactly right, so we implement it rather than argue.

PRESPECIFIED PROTOCOL (fixed before looking at the outcome):
  * Operating point: false-escalation rate (FER) = fraction of TRUE-consensus
    items flagged for review. We fix FER = 0.20 (a 20% review budget on the
    items that were actually fine) and also report 0.10 and 0.30.
  * Signal: mean_conf, flagged when LOW (low confidence => escalate).
  * Threshold selection: on a random half of the items (stratified by class),
    choose the largest tau such that the empirical FER on that half is <= the
    budget. Evaluate on the held-out half.
  * Metric: sensitivity = fraction of FALSE-consensus items caught (recall).
  * 400 random splits; report median and a 90% interval.
  * Chance baseline: flagging at random with the same FER gives sensitivity
    equal to the FER itself. We report the lift over that.

Note this metric is NOT rank-invariant: it depends on where the classes sit on
the reported scale, which is precisely the property "thresholdability" is meant
to name. Contrast it with AUC in the paper's Table.
"""
import json
import os
import random
import statistics

D = os.path.dirname(os.path.abspath(__file__))
LOGS = [
    ("3B", "exp4_3b_log.jsonl"),
    ("7B", "exp4_multilevel_log.jsonl"),
    ("14B", "exp4_14b_log.jsonl"),
    ("32B", "exp4_32b_log.jsonl"),
]
FERS = [0.10, 0.20, 0.30]
NSPLIT = 400
SEED = 0


def load(fn):
    """Return (conf, is_false) for converged items."""
    out = []
    with open(os.path.join(D, fn), encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            if not r.get("converged"):
                continue
            c = r["features"].get("mean_conf")
            if c is None:
                continue
            out.append((float(c), 0 if r.get("correct") else 1))
    return out


def pick_threshold(train, budget):
    """Largest tau with (#true-consensus with conf < tau)/n_true <= budget.

    Flag rule is conf < tau. Candidates are the observed confidences.
    """
    trues = [c for c, y in train if y == 0]
    if not trues:
        return None
    n = len(trues)
    cands = sorted(set(c for c, _ in train))
    best = None
    for tau in cands:
        fer = sum(1 for c in trues if c < tau) / n
        if fer <= budget:
            best = tau
        else:
            break
    return best


def evaluate(test, tau):
    """Return (sensitivity, realised FER) on the held-out half."""
    fs = [c for c, y in test if y == 1]
    ts = [c for c, y in test if y == 0]
    if not fs or not ts:
        return None
    sens = sum(1 for c in fs if c < tau) / len(fs)
    fer = sum(1 for c in ts if c < tau) / len(ts)
    return sens, fer


def run(data, budget, rnd):
    pos = [d for d in data if d[1] == 1]
    neg = [d for d in data if d[1] == 0]
    sens_list, fer_list = [], []
    for _ in range(NSPLIT):
        p = pos[:]
        n = neg[:]
        rnd.shuffle(p)
        rnd.shuffle(n)
        # stratified half-split so both halves contain both classes
        tr = p[: len(p) // 2] + n[: len(n) // 2]
        te = p[len(p) // 2:] + n[len(n) // 2:]
        tau = pick_threshold(tr, budget)
        if tau is None:
            continue
        r = evaluate(te, tau)
        if r is None:
            continue
        sens_list.append(r[0])
        fer_list.append(r[1])
    return sens_list, fer_list


def pct(xs, q):
    xs = sorted(xs)
    if not xs:
        return float("nan")
    i = min(len(xs) - 1, max(0, int(round(q * (len(xs) - 1)))))
    return xs[i]


def main():
    print("=" * 78)
    print("Held-out threshold performance of mean_conf (400 stratified splits)")
    print("Flag rule: escalate when mean_conf < tau; tau chosen on train half")
    print("=" * 78)

    loaded = {}
    for name, fn in LOGS:
        data = load(fn)
        loaded[name] = data
        nf = sum(y for _, y in data)
        print(f"  {name:>4}: n={len(data):3d} converged, "
              f"false={nf:3d}, true={len(data) - nf:3d}")

    for budget in FERS:
        print()
        print(f"--- false-escalation budget = {budget:.0%} "
              f"(chance sensitivity = {budget:.0%}) ---")
        print(f"  {'scale':>5} {'sens (median)':>15} {'90% interval':>18}"
              f" {'realised FER':>14} {'lift':>8}")
        for name, _ in LOGS:
            rnd = random.Random(SEED)
            sens, fer = run(loaded[name], budget, rnd)
            if not sens:
                print(f"  {name:>5}   (insufficient data)")
                continue
            med = statistics.median(sens)
            lo, hi = pct(sens, 0.05), pct(sens, 0.95)
            mfer = statistics.median(fer)
            print(f"  {name:>5} {med:>15.3f} {'[' + f'{lo:.3f}, {hi:.3f}' + ']':>18}"
                  f" {mfer:>14.3f} {med - budget:>+8.3f}")

    print()
    print("=" * 78)
    print("Reading")
    print("=" * 78)
    print("  'lift' is sensitivity minus the chance sensitivity at the same")
    print("  budget. A lift near zero means the threshold buys nothing over")
    print("  flagging at random, i.e. the signal is not usable AS A THRESHOLD")
    print("  at that operating point, regardless of its AUC.")


if __name__ == "__main__":
    main()