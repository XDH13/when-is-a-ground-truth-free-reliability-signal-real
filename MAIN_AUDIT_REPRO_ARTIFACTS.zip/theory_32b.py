"""Mathematical grounding for the two 32B-era conclusions, WITH numerical checks.

The previous theory section was cut to a remark by external review because it
(a) proved an EVT-flavoured existence result nobody disputed, and (b) "fit" two
parameters to two class means, which is a reparameterisation, not evidence.
This file deliberately avoids both failure modes:

  * Every proposition below is either an IDENTITY (provable in two lines) or an
    INEQUALITY that is checked by randomised search for counterexamples.
  * The one substantive model (Part C) is fit on STRICTLY FEWER numbers than it
    predicts, so it can fail. It is then asked to predict a DIFFERENT functional
    of the data (an AUC) than the one it was fit on (a unanimity rate).

PART A -- why the 14B "dip" is a scale artifact.
PART B -- how far a bounded scale can distort a gap, given fixed ordering.
PART C -- why agreement discriminates on MATH but not on MMLU.
"""
import json, os, math, random, collections, bisect

D = os.path.dirname(os.path.abspath(__file__))
rnd = random.Random(20260909)

SCALES = [("3B", "exp4_3b_bl.jsonl"), ("7B", "exp4_multilevel_log.jsonl"),
          ("14B", "exp4_14b_log.jsonl"), ("32B", "exp4_32b_log.jsonl")]


def load(fn):
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return None
    out = []
    for line in open(p, encoding="utf-8"):
        line = line.strip()
        if line:
            r = json.loads(line)
            if not r.get("invalid") and r.get("converged"):
                out.append(r)
    return out


def split_conf(rows):
    t = [r["features"]["mean_conf"] for r in rows if r["correct"]]
    f = [r["features"]["mean_conf"] for r in rows if not r["correct"]]
    return t, f


def auc(pos, neg):
    """P(pos > neg) + 0.5 P(pos == neg)."""
    if not pos or not neg:
        return float("nan")
    ns = sorted(neg)
    s = 0.0
    for a in pos:
        lo = bisect.bisect_left(ns, a)
        hi = bisect.bisect_right(ns, a)
        s += lo + 0.5 * (hi - lo)
    return s / (len(pos) * len(neg))


def mean(x):
    return sum(x) / len(x)


# ===================================================================== PART A
print("=" * 78)
print("PART A -- The 14B dip is a property of the SCALE, not of the ORDERING")
print("=" * 78)
print("""
Setup. Let a converged item carry a latent evidence score z, and let the
reported confidence be c = s(z) for some strictly increasing s (the model's
internal-to-verbalised map). Write T / F for true / false consensus.

  Prop A1 (rank functionals are invariant).  For any strictly increasing g,
      AUC(g(c)) = AUC(c)   exactly.
  Proof. AUC depends on c only through the events {c_T > c_F}, {c_T = c_F},
  and a strictly increasing g preserves both. []

  Prop A2 (mean gaps are NOT invariant).  D_p = E[c|T] - E[c|F] depends on s.
  In particular a pure location shift z -> z + t leaves AUC unchanged for every
  t, while, if s is bounded with s'(z) -> 0 at the ceiling,
      D_p(t) = E[s(z_T + t)] - E[s(z_F + t)] -> 0   as t -> infinity.
  Proof. AUC: immediate from Prop A1 applied to the shift. D_p: both means are
  squeezed into the shrinking interval [s(t + min z), sup s]. []

  CONSEQUENCE. "The probability gap shrank at 14B" and "the model got worse at
  ranking" are logically independent statements. A model that becomes uniformly
  more confident (a location shift) MUST show a shrinking probability gap and
  CANNOT show a changing AUC. So the 14B dip is only evidence of capability
  loss if it also appears on a rank scale -- which it does not (P = 0.593).
""")

data = {}
for name, fn in SCALES:
    rows = load(fn)
    if rows is None:
        print(f"  MISSING {fn}")
        continue
    data[name] = split_conf(rows)

print("  --- A1 verified numerically: apply 3 monotone maps, AUC must not move")
maps = [("identity", lambda x: x),
        ("logit", lambda x: math.log(min(max(x, 1e-6), 1 - 1e-6) /
                                     (1 - min(max(x, 1e-6), 1 - 1e-6)))),
        ("x^5", lambda x: x ** 5),
        ("exp(3x)", lambda x: math.exp(3 * x))]
print(f"    {'scale':<6}" + "".join(f"{n:>12}" for n, _ in maps))
for name in [s for s, _ in SCALES if s in data]:
    t, f = data[name]
    row = f"    {name:<6}"
    for _, g in maps:
        row += f"{auc([g(x) for x in t], [g(x) for x in f]):>12.6f}"
    print(row)

print()
print("  --- A2: the same four models on three scales (gap vs rank)")
print(f"    {'scale':<6}{'supp width':>12}{'prob gap':>10}{'gap/width':>11}{'AUC':>9}")
for name in [s for s, _ in SCALES if s in data]:
    t, f = data[name]
    allc = t + f
    width = max(allc) - min(allc)
    gap = mean(t) - mean(f)
    print(f"    {name:<6}{width:>12.4f}{gap:>10.4f}{gap/width:>11.4f}"
          f"{auc(t, f):>9.4f}")

# Common monotone recalibration: pooled empirical CDF. Monotone => per-scale
# AUC preserved exactly; puts every scale on ONE common ruler.
pool = sorted(v for name in data for v in (data[name][0] + data[name][1]))


def qtrans(x):
    return bisect.bisect_left(pool, x) / len(pool)


print()
print("  --- A2 test: put ALL scales on one common monotone ruler (pooled CDF)")
print("      If the 14B dip is compression, it should shrink or vanish here.")
print(f"    {'scale':<6}{'raw gap':>10}{'recal gap':>12}{'AUC before':>12}{'AUC after':>11}")
recal = {}
for name in [s for s, _ in SCALES if s in data]:
    t, f = data[name]
    rt = [qtrans(x) for x in t]
    rf = [qtrans(x) for x in f]
    recal[name] = mean(rt) - mean(rf)
    print(f"    {name:<6}{mean(t)-mean(f):>10.4f}{recal[name]:>12.4f}"
          f"{auc(t, f):>12.4f}{auc(rt, rf):>11.4f}")

if all(k in data for k in ("7B", "14B", "32B")):
    raw_dip = (mean(data["14B"][0]) - mean(data["14B"][1])) - \
              (mean(data["7B"][0]) - mean(data["7B"][1]))
    rec_dip = recal["14B"] - recal["7B"]
    print(f"\n    7B->14B dip on raw probability scale : {raw_dip:+.4f}")
    print(f"    7B->14B dip on common monotone ruler : {rec_dip:+.4f}")
    print(f"    dip explained away by rescaling      : "
          f"{100*(1 - abs(rec_dip)/abs(raw_dip)):.0f}%")

# ===================================================================== PART B
print()
print("=" * 78)
print("PART B -- How much can a bounded scale distort a gap? (searched bound)")
print("=" * 78)
print("""
  Claim B1.  If c is supported in [a,b] then |D_p| <= (b-a)(2*AUC - 1).
  This is claimed, NOT assumed: below we hunt for counterexamples by random
  search over discrete distributions. A single violation kills it.
""")
worst = 0.0
viol = 0
TRIALS = 60000
for _ in range(TRIALS):
    K = rnd.randint(2, 5)
    supp = sorted(rnd.random() for _ in range(K))
    def rdist():
        w = [rnd.random() for _ in range(K)]
        s = sum(w)
        return [x / s for x in w]
    pT, pF = rdist(), rdist()
    mT = sum(p * v for p, v in zip(pT, supp))
    mF = sum(p * v for p, v in zip(pF, supp))
    A = 0.0
    for i, vi in enumerate(supp):
        for j, vj in enumerate(supp):
            if vi > vj:
                A += pT[i] * pF[j]
            elif vi == vj:
                A += 0.5 * pT[i] * pF[j]
    width = supp[-1] - supp[0]
    if width < 1e-9:
        continue
    lhs = abs(mT - mF)
    rhs = width * abs(2 * A - 1)
    if lhs > rhs + 1e-12:
        viol += 1
    worst = max(worst, lhs - rhs)
print(f"  random search: {TRIALS} distribution pairs, violations = {viol}, "
      f"worst (lhs-rhs) = {worst:+.2e}")
print("  verdict:", "SURVIVES (usable as a proposition)" if viol == 0
      else "FALSIFIED -- do not put this in the paper")

if viol == 0 and all(k in data for k in ("14B", "32B")):
    print("\n  Applied to our data (how much gap the scale ALLOWS):")
    print(f"    {'scale':<6}{'width':>9}{'2A-1':>9}{'max |gap|':>11}"
          f"{'observed':>10}{'% of max':>10}")
    for name in [s for s, _ in SCALES if s in data]:
        t, f = data[name]
        allc = t + f
        w = max(allc) - min(allc)
        A = auc(t, f)
        cap = w * abs(2 * A - 1)
        obs = abs(mean(t) - mean(f))
        print(f"    {name:<6}{w:>9.3f}{2*A-1:>9.3f}{cap:>11.4f}"
              f"{obs:>10.4f}{100*obs/cap if cap > 0 else 0:>9.0f}%")

# ===================================================================== PART C
print()
print("=" * 78)
print("PART C -- Why agreement works on MATH and dies on MMLU")
print("=" * 78)
print("""
Setup. Fix an item. Model the 3 agents as i.i.d. draws from the item's answer
distribution q over K options. Let m = max_k q_k be the TOP MASS, and give the
remaining 1-m mass uniformly to the other K-1 options. With 3 draws,

  P(unanimous)   = m^3 + (K-1) r^3,          r = (1-m)/(K-1)
  P(exactly 2)   = 3[ m^2(1-m) + (K-1) r^2(1-r) ]
  P(all distinct)= 1 - P(unanimous) - P(exactly 2)

and the observed feature r1_agree is 1, 2/3, 1/3 on those three events.

  Prop C1. Agreement carries information about consensus correctness ONLY
  through a difference in top mass between the two groups: if m_F = m_T then
  the agreement distribution is identical in both groups and AUC = 1/2 exactly.
  Proof. The three probabilities above depend on q only via m. []

  So the question "is agreement a good signal?" reduces to "when the model's
  favourite answer is WRONG, is it less concentrated than when it is right?"
  Reasoning slips are idiosyncratic -> three samples diverge -> m_F small.
  Knowledge gaps are systematic -> three samples repeat one wrong answer ->
  m_F large.

FALSIFIABILITY. We fit ONE number per group (m_g) to ONE number per group
(the unanimity rate). We then PREDICT (i) the split between 2-1 and 1-1-1
patterns, and (ii) the AUC of agreement -- neither of which was used in the
fit. A reparameterisation cannot do this; a wrong model will miss.
""")


def pattern_probs(m, K):
    r = (1 - m) / (K - 1)
    p_un = m ** 3 + (K - 1) * r ** 3
    p_two = 3 * (m * m * (1 - m) + (K - 1) * r * r * (1 - r))
    return p_un, p_two, max(0.0, 1 - p_un - p_two)


def fit_m(p_un_obs, K):
    lo, hi = 1.0 / K, 1.0 - 1e-9
    for _ in range(200):
        mid = (lo + hi) / 2
        if pattern_probs(mid, K)[0] < p_un_obs:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def obs_patterns(rows, correct):
    sel = [r for r in rows if r["correct"] is correct]
    n = len(sel)
    if n == 0:
        return None
    c = collections.Counter()
    for r in sel:
        a = r["features"]["r1_agree"]
        c["un" if a >= 0.999 else ("two" if a >= 0.66 else "dist")] += 1
    return n, c["un"] / n, c["two"] / n, c["dist"] / n


def pred_auc(pF, pT):
    """AUC = P(agree_F < agree_T) + .5 P(=) over the 3-point distributions."""
    vals = [1 / 3, 2 / 3, 1.0]
    a = 0.0
    for i, vi in enumerate(vals):
        for j, vj in enumerate(vals):
            if vj > vi:
                a += pF[i] * pT[j]
            elif vj == vi:
                a += 0.5 * pF[i] * pT[j]
    return a


CASES = [("MATH 32b", "exp4_32b_log.jsonl", 30),
         ("MMLU 32b", "mmlu_32b_log.jsonl", 4),
         ("ARC mistral", "arc_mistral_log.jsonl", 4)]

for name, fn, K in CASES:
    rows = load(fn)
    if not rows:
        print(f"  {name}: MISSING")
        continue
    oF, oT = obs_patterns(rows, False), obs_patterns(rows, True)
    if not oF or not oT:
        continue
    nF, unF, twoF, distF = oF
    nT, unT, twoT, distT = oT
    mF, mT = fit_m(unF, K), fit_m(unT, K)
    pF, pT = pattern_probs(mF, K), pattern_probs(mT, K)
    # observed AUC of r1_agree, oriented as P(agree_T > agree_F)
    agT = [r["features"]["r1_agree"] for r in rows if r["correct"]]
    agF = [r["features"]["r1_agree"] for r in rows if not r["correct"]]
    obsA = auc(agT, agF)
    prdA = pred_auc((pF[2], pF[1], pF[0]), (pT[2], pT[1], pT[0]))
    print(f"  --- {name}   (K={K}, n_false={nF}, n_true={nT})")
    print(f"      FIT   : m_false={mF:.3f}   m_true={mT:.3f}   "
          f"(each fit to 1 number: the unanimity rate)")
    print(f"      CHECK   2-1 pattern   obs F={twoF:.3f} pred {pF[1]:.3f}  |  "
          f"obs T={twoT:.3f} pred {pT[1]:.3f}")
    print(f"      CHECK   1-1-1 pattern obs F={distF:.3f} pred {pF[2]:.3f}  |  "
          f"obs T={distT:.3f} pred {pT[2]:.3f}")
    print(f"      PREDICT agreement AUC  observed={obsA:.3f}  "
          f"predicted={prdA:.3f}  error={prdA-obsA:+.3f}")
    print()

print("  Sensitivity of the MATH fit to the assumed option count K:")
rows = load("exp4_32b_log.jsonl")
if rows:
    oF, oT = obs_patterns(rows, False), obs_patterns(rows, True)
    for K in (4, 10, 30, 100):
        mF, mT = fit_m(oF[1], K), fit_m(oT[1], K)
        print(f"    K={K:>4}: m_false={mF:.3f} m_true={mT:.3f} "
              f"(gap {mT-mF:+.3f})")