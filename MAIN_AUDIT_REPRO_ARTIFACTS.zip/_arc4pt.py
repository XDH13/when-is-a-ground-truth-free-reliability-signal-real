"""Cross-domain (ARC) analysis at the 32B scale point, with an explicit
POWER CHECK first.

Why the power check comes first: the 32B ARC run produced only 7 false-consensus
items out of 240 (and ZERO on ARC-Easy). With 7 positives, an AUC point estimate
is nearly meaningless -- its bootstrap CI will span most of [0.5, 1.0]. Reporting
"agreement survives on ARC at 32B" from 7 items would be exactly the kind of
low-base-rate illusion the external reviewer already flagged once on the 14B run.

So this script:
  1. reports base rates and states whether each cell has enough positives;
  2. computes AUCs WITH bootstrap CIs (not bare point estimates);
  3. compares against the smaller-scale ARC runs (qwen 7b / llama / mistral)
     to see whether the signal is intact where power actually exists.
"""
import json, os, math, random, bisect, collections

D = os.path.dirname(os.path.abspath(__file__))
B = 20000
SEED = 20260908
MIN_POS = 15          # below this, we refuse to interpret an AUC

LOGS = [
    ("ARC 32b",    "arc_32b_log.jsonl"),
    ("MMLU 32b",   "mmlu_32b_log.jsonl"),   # replacement cross-domain cell
    ("ARC qwen7b", "arc_qwen_log.jsonl"),
    ("ARC llama",  "arc_llama_log.jsonl"),
    ("ARC mistral","arc_mistral_log.jsonl"),
    ("MATH 32b",   "exp4_32b_log.jsonl"),
]


def load(fn):
    rows = []
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return None
    for line in open(p, encoding="utf-8"):
        line = line.strip()
        if not line:
            continue
        r = json.loads(line)
        if not r.get("invalid") and r.get("converged"):
            rows.append(r)
    return rows


def auc(pos, neg):
    """P(pos > neg), ties=0.5. pos = scores of FALSE consensus (y=1)."""
    n = len(pos) * len(neg)
    if n == 0:
        return float("nan")
    negs = sorted(neg)
    s = 0.0
    for a in pos:
        lo = bisect.bisect_left(negs, a)
        hi = bisect.bisect_right(negs, a)
        s += lo + 0.5 * (hi - lo)
    return s / n


def strat_auc(y, sc, strata):
    conc = 0.0
    total = 0
    by = collections.defaultdict(list)
    for i in range(len(y)):
        by[strata[i]].append(i)
    for _, idxs in by.items():
        pos = [i for i in idxs if y[i] == 1]
        neg = [i for i in idxs if y[i] == 0]
        for p in pos:
            for nn in neg:
                total += 1
                conc += 1 if sc[p] > sc[nn] else (0.5 if sc[p] == sc[nn] else 0)
    if total == 0:
        return None, 0
    return max(conc / total, 1 - conc / total), total


def ci(vals, a=0.025):
    v = sorted(vals)
    return v[int(a * len(v))], v[int((1 - a) * len(v)) - 1]


rnd = random.Random(SEED)

print("=" * 78)
print("STEP 1 -- BASE RATES AND STATISTICAL POWER")
print("=" * 78)
print(f"{'dataset':<13}{'conv':>6}{'false':>7}{'rate':>8}   verdict")
print("-" * 78)
store = {}
for name, fn in LOGS:
    rows = load(fn)
    if rows is None:
        print(f"{name:<13}  MISSING {fn}")
        continue
    y = [1 if not r["correct"] else 0 for r in rows]
    npos = sum(y)
    store[name] = rows
    verdict = ("OK" if npos >= MIN_POS
               else f"UNDERPOWERED (<{MIN_POS} positives) -- do not interpret")
    print(f"{name:<13}{len(rows):>6}{npos:>7}{npos/len(rows):>8.3f}   {verdict}")

print()
print("=" * 78)
print("STEP 2 -- AGREEMENT SIGNAL WITH BOOTSTRAP CIs (not bare point estimates)")
print("=" * 78)
print(f"{'dataset':<13}{'feature':<11}{'AUC':>7}{'95% CI':>20}{'pairs':>8}  note")
print("-" * 78)
for name, _ in LOGS:
    if name not in store:
        continue
    rows = store[name]
    y = [1 if not r["correct"] else 0 for r in rows]
    lv = [int(r.get("level", 0)) for r in rows]
    npos = sum(y)
    for feat in ("r1_agree", "r2_agree", "mean_conf"):
        sc = [r["features"][feat] for r in rows]
        a_wl, pairs = strat_auc(y, sc, lv)
        if a_wl is None:
            print(f"{name:<13}{feat:<11}{'n/a':>7}{'':>20}{0:>8}  no within-level pairs")
            continue
        # bootstrap the stratified AUC
        idx_by = collections.defaultdict(list)
        for i in range(len(y)):
            idx_by[lv[i]].append(i)
        draws = []
        for _ in range(2000):
            yy, ss, ll = [], [], []
            for st, idxs in idx_by.items():
                for _ in range(len(idxs)):
                    j = idxs[rnd.randrange(len(idxs))]
                    yy.append(y[j]); ss.append(sc[j]); ll.append(lv[j])
            v, _p = strat_auc(yy, ss, ll)
            if v is not None:
                draws.append(v)
        lo, hi = ci(draws) if draws else (float("nan"), float("nan"))
        note = "" if npos >= MIN_POS else "UNDERPOWERED"
        print(f"{name:<13}{feat:<11}{a_wl:>7.3f}"
              f"{f'[{lo:.3f}, {hi:.3f}]':>20}{pairs:>8}  {note}")

print()
print("=" * 78)
print("READING")
print("=" * 78)
print("ARC at 32B is a CEILING cell: near-perfect accuracy leaves almost no")
print("false-consensus items, so it cannot test the signal. That is a fact about")
print("the benchmark-model pairing, not evidence for or against the claim.")
print("The cross-domain claim must rest on the ARC cells that have real positives.")