"""Exp 4 STRICT check: within-Level stratified AUC.

Linear residualization on an ordinal 5-bin Level can leave within-bin
difficulty variance uncontrolled -> a difficulty proxy can look like it
"survives". The clean test: does the signal still separate FALSE from TRUE
consensus WITHIN each difficulty Level? If it collapses to ~0.5 inside levels,
its whole apparent signal was between-level difficulty (a proxy).

Pools within-level rankings via a stratified Mann-Whitney (compare pairs only
inside the same Level), which is immune to between-level difficulty entirely.
"""
import os, json, collections
from exp0_analyze import eff_auc

LOG = os.path.join(os.path.dirname(__file__),
                   os.environ.get("EXP4_LOG", "exp4_multilevel_log.jsonl"))
FEATS = ["r2_agree", "r1_agree", "agree_slope", "r1_div", "r2_div",
         "div_slope", "mean_conf", "conf_var"]


def load():
    rows = []
    for line in open(LOG, encoding="utf-8"):
        line = line.strip()
        if line:
            r = json.loads(line)
            if not r.get("invalid") and r.get("converged"):
                rows.append(r)
    return rows


def stratified_auc(y, s, strata):
    """Direction-agnostic AUC pooled ONLY within strata (same Level).
    Counts concordant pairs (pos>neg) among same-level pos/neg pairs."""
    conc = 0.0; total = 0
    by = collections.defaultdict(list)
    for i in range(len(y)):
        by[strata[i]].append(i)
    for g, idxs in by.items():
        pos = [i for i in idxs if y[i] == 1]
        neg = [i for i in idxs if y[i] == 0]
        for p in pos:
            for n in neg:
                total += 1
                if s[p] > s[n]:
                    conc += 1
                elif s[p] == s[n]:
                    conc += 0.5
    if total == 0:
        return None, 0
    a = conc / total
    return max(a, 1 - a), total


def main():
    rows = load()
    y = [1 if not r.get("correct") else 0 for r in rows]
    lv = [int(r.get("level", 0)) for r in rows]
    n = len(rows)
    print("=" * 70)
    print(f"Exp 4 WITHIN-LEVEL stratified AUC   n={n} (FALSE={sum(y)}, TRUE={n-sum(y)})")
    print("If a signal is JUST a difficulty proxy, within-level |AUC| -> ~0.5")
    print("=" * 70)
    # per-level class counts (how many usable same-level pos/neg pairs exist)
    cnt = collections.Counter(lv)
    fc = collections.Counter(lv[i] for i in range(n) if y[i] == 1)
    print("level (n, FALSE):", {L: (cnt[L], fc.get(L, 0)) for L in sorted(cnt)})
    print(f"\n{'signal':12s} {'pooled_raw':>11s} {'within_lvl':>11s} {'#pairs':>7s}  drop")
    print("-" * 70)
    for f in FEATS:
        s = [float(r["features"][f]) for r in rows]
        _, raw = eff_auc(y, s)
        w, npairs = stratified_auc(y, s, lv)
        if w is None:
            print(f"{f:12s} {raw:11.3f} {'n/a':>11s} {npairs:7d}")
            continue
        drop = raw - w
        mark = "  <== survives within-level" if w >= 0.62 else ""
        print(f"{f:12s} {raw:11.3f} {w:11.3f} {npairs:7d}  {drop:+.3f}{mark}")
    # ---- stratified permutation FWER: shuffle y WITHIN each level ----
    import random
    rng = random.Random(13)
    winner = max(FEATS, key=lambda f: stratified_auc(y, [float(r["features"][f]) for r in rows], lv)[0] or 0)
    ws = [float(r["features"][winner]) for r in rows]
    obs, _ = stratified_auc(y, ws, lv)
    by = collections.defaultdict(list)
    for i in range(n):
        by[lv[i]].append(i)
    NP = 2000
    hits = 0
    for _ in range(NP):
        yp = list(y)
        for g, idxs in by.items():          # permute labels only within a level
            vals = [yp[i] for i in idxs]
            rng.shuffle(vals)
            for k, i in enumerate(idxs):
                yp[i] = vals[k]
        best = 0.0
        for f in FEATS:
            s = [float(r["features"][f]) for r in rows]
            w, _ = stratified_auc(yp, s, lv)
            if w:
                best = max(best, w)
        if best >= obs - 1e-9:
            hits += 1
    fwer = hits / NP
    print(f"\nwithin-level winner: {winner} |AUC|={obs:.3f}")
    print(f"stratified permutation FWER (any signal >= {obs:.3f}, y shuffled "
          f"within level): {fwer:.3f}")
    print("\n(within_lvl >= ~0.62 => genuine difficulty-independent signal;")
    print(" within_lvl ~0.5 => the raw separability was between-level difficulty.)")


if __name__ == "__main__":
    main()
