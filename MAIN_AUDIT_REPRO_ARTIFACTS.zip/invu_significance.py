"""Is the inverted-U statistically real? Bootstrap the RISING arm (3B->7B) and the
FALLING arm (7B->14B) separately, on BOTH the probability scale (what the paper
reports) and the logit scale (unbounded, = 2*beta*mu under the calibration model),
plus a monotone-invariant AUC check.

Motivation: the paper's headline methodological claim is "a two-point study would
have reported a monotone trend and drawn the wrong conclusion". That claim rests
ENTIRELY on the falling arm being real. If the fall is within noise, the claim
must be weakened. This script decides that, honestly.

Also runs a joint test: bootstrap P(gap_7B > gap_3B AND gap_7B > gap_14B), i.e.
the probability that 7B is the interior peak.
"""
import json, math, os, random

LOGS = [
    ("3B", "exp4_3b_bl.jsonl"),
    ("7B", "exp4_multilevel_log.jsonl"),
    ("14B", "exp4_14b_log.jsonl"),
]
B = 20000
SEED = 20260907


def logit(p, eps=1e-6):
    p = min(max(p, eps), 1 - eps)
    return math.log(p / (1 - p))


def load(path):
    tc, fc = [], []
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                r = json.loads(line)
            except Exception:
                continue
            if r.get("invalid") or not r.get("converged"):
                continue
            (tc if r.get("correct") else fc).append(r["features"]["mean_conf"])
    return tc, fc


def mean(xs):
    return sum(xs) / len(xs)


def auc(pos, neg):
    n = len(pos) * len(neg)
    if n == 0:
        return float("nan")
    neg_s = sorted(neg)
    s = 0.0
    import bisect
    for a in pos:
        lo = bisect.bisect_left(neg_s, a)
        hi = bisect.bisect_right(neg_s, a)
        s += lo + 0.5 * (hi - lo)
    return s / n


def gap_prob(tc, fc):
    return mean(tc) - mean(fc)


def gap_logit(tc, fc):
    return logit(mean(tc)) - logit(mean(fc))


def ci(vals, a=0.025):
    vals = sorted(vals)
    return vals[int(a * len(vals))], vals[int((1 - a) * len(vals)) - 1]


def main():
    data = {}
    for scale, path in LOGS:
        if not os.path.exists(path):
            print("MISSING", path)
            return
        data[scale] = load(path)

    rnd = random.Random(SEED)

    def resample(xs):
        return [xs[rnd.randrange(len(xs))] for _ in range(len(xs))]

    for name, stat in [("probability-scale gap", gap_prob),
                       ("logit-scale gap (=2*beta*mu)", gap_logit),
                       ("AUC (monotone-invariant)", auc)]:
        print(f"\n=== {name} ===")
        point = {s: stat(*data[s]) for s in data}
        for s in data:
            print(f"  {s:<5} point estimate = {point[s]:+.4f}")

        draws = {s: [] for s in data}
        for _ in range(B):
            for s in data:
                tc, fc = data[s]
                draws[s].append(stat(resample(tc), resample(fc)))

        for s in data:
            lo, hi = ci(draws[s])
            print(f"  {s:<5} 95% CI = [{lo:+.4f}, {hi:+.4f}]")

        rise = [draws["7B"][i] - draws["3B"][i] for i in range(B)]
        fall = [draws["14B"][i] - draws["7B"][i] for i in range(B)]
        lo_r, hi_r = ci(rise)
        lo_f, hi_f = ci(fall)
        p_rise = sum(1 for d in rise if d > 0) / B
        p_fall = sum(1 for d in fall if d < 0) / B
        print(f"  RISING arm  3B->7B : {point['7B'] - point['3B']:+.4f} "
              f"CI [{lo_r:+.4f}, {hi_r:+.4f}]  P(rise>0)={p_rise:.3f}  "
              f"{'SIGNIFICANT' if lo_r > 0 else 'n.s.'}")
        print(f"  FALLING arm 7B->14B: {point['14B'] - point['7B']:+.4f} "
              f"CI [{lo_f:+.4f}, {hi_f:+.4f}]  P(fall<0)={p_fall:.3f}  "
              f"{'SIGNIFICANT' if hi_f < 0 else 'n.s.'}")
        p_peak = sum(1 for i in range(B)
                     if draws["7B"][i] > draws["3B"][i]
                     and draws["7B"][i] > draws["14B"][i]) / B
        print(f"  JOINT: P(7B is the interior peak) = {p_peak:.3f}")

    print("\n--- HONEST READING ---")
    print("If the rising arm is significant but the falling arm is not, then the")
    print("data support 'confidence separation is NOT monotonically increasing and")
    print("plateaus/does not improve beyond 7B', but do NOT establish a strict")
    print("interior peak. The paper's 'two points would mislead' claim must be")
    print("restated around the 3B end (which IS significant), not the 14B end.")


if __name__ == "__main__":
    main()