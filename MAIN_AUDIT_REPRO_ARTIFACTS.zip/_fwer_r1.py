"""FWER for the r1_agree row specifically.

exp4_within.py computes the max-statistic FWER at the *winner's* observed
within-Level AUC. At 14B the winner is r2_agree (0.789), not r1_agree (0.724),
so that p-value does NOT license the r1_agree cell of tab:main -- lowering the
threshold can only raise a max-statistic FWER. This script re-runs the same
within-Level label permutation but sets the threshold to r1_agree's own
observed value at each scale. Run each scale in a fresh interpreter because
exp4_within resolves EXP4_LOG at import time.
"""
import os, sys, json, collections, random

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from exp4_within import stratified_auc, FEATS  # identical estimator

NP = 2000
TARGET = "r1_agree"
LOGS = [("3B", "exp4_3b_log.jsonl"), ("7B", "exp4_multilevel_log.jsonl"),
        ("14B", "exp4_14b_log.jsonl"), ("32B", "exp4_32b_log.jsonl")]


def load(fn):
    rows = []
    for line in open(os.path.join(HERE, fn), encoding="utf-8"):
        line = line.strip()
        if line:
            r = json.loads(line)
            if not r.get("invalid") and r.get("converged"):
                rows.append(r)
    return rows


for name, fn in LOGS:
    rows = load(fn)
    y = [1 if not r.get("correct") else 0 for r in rows]
    lv = [int(r.get("level", 0)) for r in rows]
    feats = {f: [float(r["features"][f]) for r in rows] for f in FEATS}
    obs, npairs = stratified_auc(y, feats[TARGET], lv)

    by = collections.defaultdict(list)
    for i in range(len(rows)):
        by[lv[i]].append(i)

    rng = random.Random(13)
    hits = 0
    for _ in range(NP):
        yp = list(y)
        for g, idxs in by.items():
            vals = [yp[i] for i in idxs]
            rng.shuffle(vals)
            for k, i in enumerate(idxs):
                yp[i] = vals[k]
        best = 0.0
        for f in FEATS:
            w, _ = stratified_auc(yp, feats[f], lv)
            if w:
                best = max(best, w)
        if best >= obs - 1e-9:
            hits += 1
    print(f"{name:4s} n={len(rows):4d} pairs={npairs:5d} {TARGET} "
          f"within-Level |AUC|={obs:.3f}  "
          f"FWER(any >= {obs:.3f}) = {hits}/{NP} = {hits/NP:.4f}")