"""Follow-up after theory_32b.py, which produced two negative results:

  (i)  PART B's claimed inequality |D_p| <= (b-a)(2*AUC-1) was FALSIFIED by
       random search (9911/60000 violations). It is dropped, not patched.
  (ii) PART A's rescaling test BACKFIRED: on a common monotone ruler the
       7B->14B dip did not shrink, it GREW (-0.025 -> -0.066). So "the dip is
       a ceiling artifact" -- the story in SCALE32B_RESULT.md -- is too strong.

This script settles (ii) properly and stress-tests PART C's model.

Q1. Is the 14B dip a SPREAD effect (confidence squeezed into a narrow band) or
    a DISCRIMINATION effect? Compare raw gap, gap standardised by pooled SD,
    and AUC. A pure spread effect moves the raw gap but not the standardised
    gap or the AUC.
Q2. Does PART C's one-parameter model survive controls (label shuffle) and
    bootstrap, or is its accurate AUC prediction luck?
"""
import json, os, math, random, collections, bisect

D = os.path.dirname(os.path.abspath(__file__))
rnd = random.Random(20260909)

SCALES = [("3B", "exp4_3b_bl.jsonl"), ("7B", "exp4_multilevel_log.jsonl"),
          ("14B", "exp4_14b_log.jsonl"), ("32B", "exp4_32b_log.jsonl")]


def load(fn):
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return None
    out = []
    for line in open(p, encoding="utf-8"):
        line = line.strip()
        if line:
            r = json.loads(line)
            if not r.get("invalid") and r.get("converged"):
                out.append(r)
    return out


def auc(pos, neg):
    if not pos or not neg:
        return float("nan")
    ns = sorted(neg)
    s = 0.0
    for a in pos:
        lo = bisect.bisect_left(ns, a)
        hi = bisect.bisect_right(ns, a)
        s += lo + 0.5 * (hi - lo)
    return s / (len(pos) * len(neg))


def mean(x):
    return sum(x) / len(x)


def sd(x):
    if len(x) < 2:
        return 0.0
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (len(x) - 1))


def ci(v, a=0.025):
    v = sorted(v)
    return v[int(a * len(v))], v[int((1 - a) * len(v)) - 1]


print("=" * 78)
print("Q1 -- Is the 14B dip SPREAD or DISCRIMINATION?")
print("=" * 78)
print("""
  Decomposition. Write the standardised gap  d = (E[c|T] - E[c|F]) / SD(c).
  For two groups, d and AUC are tied together (both are location-over-spread
  summaries), whereas the RAW gap additionally carries the absolute spread.
  So:
     raw gap dips but d and AUC flat  ->  pure SPREAD compression
     d and AUC dip too                ->  genuine DISCRIMINATION loss
""")
data = {}
for name, fn in SCALES:
    rows = load(fn)
    if rows is None:
        print(f"  MISSING {fn}")
        continue
    t = [r["features"]["mean_conf"] for r in rows if r["correct"]]
    f = [r["features"]["mean_conf"] for r in rows if not r["correct"]]
    data[name] = (t, f)

print(f"  {'scale':<6}{'SD(all)':>9}{'raw gap':>10}{'std gap d':>11}"
      f"{'AUC':>9}{'n_F':>6}")
print("  " + "-" * 51)
for name, _ in SCALES:
    if name not in data:
        continue
    t, f = data[name]
    allc = t + f
    s = sd(allc)
    g = mean(t) - mean(f)
    print(f"  {name:<6}{s:>9.4f}{g:>10.4f}{g/s if s else 0:>11.4f}"
          f"{auc(t, f):>9.4f}{len(f):>6}")

print("\n  bootstrap 95% CI on the standardised gap d (2000 draws):")
for name, _ in SCALES:
    if name not in data:
        continue
    t, f = data[name]
    ds = []
    for _ in range(2000):
        bt = [t[rnd.randrange(len(t))] for _ in range(len(t))]
        bf = [f[rnd.randrange(len(f))] for _ in range(len(f))]
        s = sd(bt + bf)
        if s > 0:
            ds.append((mean(bt) - mean(bf)) / s)
    lo, hi = ci(ds)
    print(f"    {name:<5} d = {mean(ds):+.3f}  CI [{lo:+.3f}, {hi:+.3f}]")

if all(k in data for k in ("7B", "14B")):
    # NOT paired: the two scales have disjoint converged item sets, so each arm
    # is resampled independently from its own pool (see bAt/bAf below). Pairing
    # would be invalid here; the label used to say "paired" and was wrong.
    print("\n  independent-resampling bootstrap of the 7B->14B change,"
          " three statistics:")
    t7, f7 = data["7B"]
    t14, f14 = data["14B"]
    draws = {"raw": [], "std": [], "auc": []}
    for _ in range(4000):
        b7t = [t7[rnd.randrange(len(t7))] for _ in range(len(t7))]
        b7f = [f7[rnd.randrange(len(f7))] for _ in range(len(f7))]
        bAt = [t14[rnd.randrange(len(t14))] for _ in range(len(t14))]
        bAf = [f14[rnd.randrange(len(f14))] for _ in range(len(f14))]
        g7, gA = mean(b7t) - mean(b7f), mean(bAt) - mean(bAf)
        s7, sA = sd(b7t + b7f), sd(bAt + bAf)
        draws["raw"].append(gA - g7)
        if s7 > 0 and sA > 0:
            draws["std"].append(gA / sA - g7 / s7)
        draws["auc"].append(auc(bAt, bAf) - auc(b7t, b7f))
    for k, lab in [("raw", "raw gap"), ("std", "standardised gap d"),
                   ("auc", "AUC")]:
        lo, hi = ci(draws[k])
        m = mean(draws[k])
        v = "SIGNIF drop" if hi < 0 else ("SIGNIF rise" if lo > 0 else "n.s.")
        print(f"    {lab:<20} {m:+.4f}  CI [{lo:+.4f}, {hi:+.4f}]  {v}")

print()
print("=" * 78)
print("Q2 -- Stress-test PART C's one-parameter model")
print("=" * 78)


def pattern_probs(m, K):
    r = (1 - m) / (K - 1)
    p_un = m ** 3 + (K - 1) * r ** 3
    p_two = 3 * (m * m * (1 - m) + (K - 1) * r * r * (1 - r))
    return p_un, p_two, max(0.0, 1 - p_un - p_two)


def fit_m(p_un_obs, K):
    lo, hi = 1.0 / K, 1.0 - 1e-9
    for _ in range(200):
        mid = (lo + hi) / 2
        if pattern_probs(mid, K)[0] < p_un_obs:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def pred_auc_from_m(mF, mT, K):
    pF = pattern_probs(mF, K)
    pT = pattern_probs(mT, K)
    # order the 3-point support ascending: 1/3 (all distinct), 2/3, 1
    fv = (pF[2], pF[1], pF[0])
    tv = (pT[2], pT[1], pT[0])
    a = 0.0
    for i in range(3):
        for j in range(3):
            if j > i:
                a += fv[i] * tv[j]
            elif j == i:
                a += 0.5 * fv[i] * tv[j]
    return a


def unan_rate(rows, correct):
    sel = [r for r in rows if r["correct"] is correct]
    if not sel:
        return None
    return sum(1 for r in sel
               if r["features"]["r1_agree"] >= 0.999) / len(sel)


CASES = [("MATH 32b", "exp4_32b_log.jsonl", 30),
         ("MMLU 32b", "mmlu_32b_log.jsonl", 4),
         ("ARC mistral", "arc_mistral_log.jsonl", 4)]

print(f"  {'dataset':<13}{'obs AUC':>9}{'pred AUC':>10}{'err':>8}"
      f"{'err 95% CI':>20}{'shuffle pred':>14}")
print("  " + "-" * 74)
for name, fn, K in CASES:
    rows = load(fn)
    if not rows:
        continue
    agT = [r["features"]["r1_agree"] for r in rows if r["correct"]]
    agF = [r["features"]["r1_agree"] for r in rows if not r["correct"]]
    obsA = auc(agT, agF)
    prd = pred_auc_from_m(fit_m(unan_rate(rows, False), K),
                          fit_m(unan_rate(rows, True), K), K)
    # bootstrap the prediction error
    errs = []
    for _ in range(2000):
        bt = [agT[rnd.randrange(len(agT))] for _ in range(len(agT))]
        bf = [agF[rnd.randrange(len(agF))] for _ in range(len(agF))]
        uT = sum(1 for a in bt if a >= 0.999) / len(bt)
        uF = sum(1 for a in bf if a >= 0.999) / len(bf)
        errs.append(pred_auc_from_m(fit_m(uF, K), fit_m(uT, K), K)
                    - auc(bt, bf))
    lo, hi = ci(errs)
    # CONTROL: shuffle correctness labels -> model must predict AUC ~ 0.5
    pool = agT + agF
    sh = []
    for _ in range(400):
        p = pool[:]
        rnd.shuffle(p)
        st, sf = p[:len(agT)], p[len(agT):]
        uT = sum(1 for a in st if a >= 0.999) / len(st)
        uF = sum(1 for a in sf if a >= 0.999) / len(sf)
        sh.append(pred_auc_from_m(fit_m(uF, K), fit_m(uT, K), K))
    print(f"  {name:<13}{obsA:>9.3f}{prd:>10.3f}{prd-obsA:>+8.3f}"
          f"{f'[{lo:+.3f}, {hi:+.3f}]':>20}{mean(sh):>14.3f}")

print("""
  Reading: the model is fit to ONE number per group (the unanimity rate) and
  then asked to reproduce the AUC, a different functional of a distribution
  with 2 free parameters per group. If the errors straddle zero and the label
  -shuffle control lands at 0.5, the pipeline passes this sanity check. Because
  agreement AUC is dominated by the unanimity contrast used for fitting, this
  is not fully independent evidence or a formal power analysis.
""")

print("=" * 78)
print("Q2b -- fitted top mass as a restricted-model diagnostic")
print("=" * 78)
print(f"  {'dataset':<13}{'m_false':>9}{'m_true':>9}{'m_T - m_F':>11}{'AUC':>8}")
print("  " + "-" * 50)
pts = []
for name, fn, K in CASES:
    rows = load(fn)
    if not rows:
        continue
    mF = fit_m(unan_rate(rows, False), K)
    mT = fit_m(unan_rate(rows, True), K)
    agT = [r["features"]["r1_agree"] for r in rows if r["correct"]]
    agF = [r["features"]["r1_agree"] for r in rows if not r["correct"]]
    a = auc(agT, agF)
    pts.append((mT - mF, a))
    print(f"  {name:<13}{mF:>9.3f}{mT:>9.3f}{mT-mF:>+11.3f}{a:>8.3f}")
print("""
  Prop C1 says AUC = 1/2 exactly when m_T = m_F under the uniform-tail model.
  The three observed domains line up in (m_T - m_F), a pattern consistent with
  the "independent slips vs shared knowledge gap" hypothesis. The proposition
  does not prove monotonicity in the difference, and three domains do not
  establish the taxonomy.
""")
