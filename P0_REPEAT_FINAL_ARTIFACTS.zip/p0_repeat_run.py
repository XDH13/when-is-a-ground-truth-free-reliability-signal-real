"""Post-review independent-generation replication runner.

The fixed seeds below determine only item order.  No seed is passed to Ollama;
every model response is a new stochastic generation, saved to fresh JSONL logs.
This repeat was added during revision; it was not preregistered.
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STATUS = ROOT / "P0_REPEAT_STATUS.json"
START = time.time()


def update(step, state, **extra):
    payload = {"step": step, "state": state,
               "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
               "elapsed_hours": round((time.time() - START) / 3600, 3), **extra}
    temp = STATUS.with_suffix(".json.tmp")
    temp.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    os.replace(temp, STATUS)
    print("STATUS", json.dumps(payload), flush=True)


def run(step, script, env):
    update(step, "RUNNING", script=script)
    merged = os.environ.copy(); merged.update(env)
    p = subprocess.run([sys.executable, script], cwd=ROOT, env=merged)
    if p.returncode:
        update(step, "FAILED", returncode=p.returncode)
        raise SystemExit(p.returncode)
    update(step, "COMPLETE")


def main():
    update("initialise", "RUNNING", protocol="independent stochastic replication v1")
    math = [("qwen3", "qwen2.5:3b-instruct"),
            ("qwen7", "qwen2.5:7b-instruct"),
            ("qwen14", "qwen2.5:14b-instruct")]
    for tag, model in math:
        run(f"math_{tag}", "exp4_collect.py", {
            "EXP0_MODEL": model, "EXP4_LOG": f"repeat_math_{tag}.jsonl",
            "EXP4_LIMIT": "240", "EXP0_SEED": "20260911"})
    mmlu = [("qwen3", "qwen2.5:3b-instruct"),
            ("qwen7", "qwen2.5:7b-instruct"),
            ("qwen14", "qwen2.5:14b-instruct"),
            ("llama8", "llama3.1:8b"),
            ("mistral7", "mistral:7b-instruct")]
    for tag, model in mmlu:
        run(f"mmlu_{tag}", "p0_mcq_collect.py", {
            "EXP0_MODEL": model, "P0_MCQ_POOL": "mmlu_holdout_pool.json",
            "P0_MCQ_LOG": f"repeat_mmlu_{tag}.jsonl", "P0_MCQ_LIMIT": "200",
            "P0_DOMAIN": "mmlu-holdout", "P0_MCQ_SEED": "20260911",
            "P0_MCQ_MAX_TOKENS": "128"})
    run("analysis", "p0_repeat_analyze.py", {})
    update("all", "COMPLETE")


if __name__ == "__main__":
    main()
