"""Compare archived original and independently generated repeat traces."""
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
SEED = 20260911
SPECS = {
    "MATH / Qwen2.5-3B": ("exp4_3b_log.jsonl", "repeat_math_qwen3.jsonl"),
    "MATH / Qwen2.5-7B": ("exp4_multilevel_log.jsonl", "repeat_math_qwen7.jsonl"),
    "MATH / Qwen2.5-14B": ("exp4_14b_log.jsonl", "repeat_math_qwen14.jsonl"),
    "MMLU / Qwen2.5-3B": ("p0_mmlu_holdout_qwen3.jsonl", "repeat_mmlu_qwen3.jsonl"),
    "MMLU / Qwen2.5-7B": ("p0_mmlu_holdout_qwen7.jsonl", "repeat_mmlu_qwen7.jsonl"),
    "MMLU / Qwen2.5-14B": ("p0_mmlu_holdout_qwen14.jsonl", "repeat_mmlu_qwen14.jsonl"),
    "MMLU / Llama-3.1-8B": ("p0_mmlu_holdout_llama8.jsonl", "repeat_mmlu_llama8.jsonl"),
    "MMLU / Mistral-7B": ("p0_mmlu_holdout_mistral7.jsonl", "repeat_mmlu_mistral7.jsonl"),
}


def load(name):
    rows = []
    for line in (ROOT / name).read_text(encoding="utf-8").splitlines():
        try:
            r = json.loads(line)
            if not r.get("invalid"):
                rows.append(r)
        except json.JSONDecodeError:
            pass
    return rows


def auc(t, f):
    if not t or not f:
        return float("nan")
    x, y = np.asarray(t)[:, None], np.asarray(f)[None, :]
    return float(((x > y) + .5 * (x == y)).mean())


def strat(rows):
    rows = [r for r in rows if r.get("converged")]
    num = den = 0
    for level in sorted({int(r["level"]) for r in rows}):
        tr = [r["features"]["r1_agree"] for r in rows if int(r["level"]) == level and r["correct"]]
        fa = [r["features"]["r1_agree"] for r in rows if int(r["level"]) == level and not r["correct"]]
        if tr and fa:
            w = len(tr) * len(fa); num += auc(tr, fa) * w; den += w
    return num / den if den else float("nan")


def summary(rows):
    c = [r for r in rows if r.get("converged")]
    return len(rows), len(c), sum(not r.get("correct") for r in c), strat(rows)


def paired_delta(old, new, draws=5000):
    # Resample common items within official/tier stratum.  This is descriptive:
    # each trace can select a different converged subset.
    old, new = {r["q"]: r for r in old}, {r["q"]: r for r in new}
    common = [q for q in old if q in new]
    cells = {}
    for q in common:
        key = int(old[q]["level"])
        cells.setdefault(key, []).append(q)
    rng = np.random.default_rng(SEED)
    ds = []
    for _ in range(draws):
        a = []; b = []
        for qs in cells.values():
            picks = rng.integers(0, len(qs), len(qs))
            a.extend(old[qs[i]] for i in picks); b.extend(new[qs[i]] for i in picks)
        d = strat(b) - strat(a)
        if np.isfinite(d): ds.append(d)
    return common, np.quantile(ds, [.025, .975]).tolist() if ds else [float("nan"), float("nan")]


def main():
    out = {"protocol": "new unseeded Ollama generations; fixed seeds order items only", "cells": {}}
    lines = ["# Independent stochastic-generation replication", "",
             "Each repeat uses fresh JSONL files and new Ollama generations. Fixed seeds control item order only.",
             "Intervals below are paired item-bootstrap differences conditional on the two archived traces; they do not estimate a broader generation distribution.", "",
             "| setting | original (items / conv / false / AUC) | repeat (items / conv / false / AUC) | repeat minus original AUC, 95% item-bootstrap CI |", "|---|---|---|---|"]
    for name, (a, b) in SPECS.items():
        old, new = load(a), load(b)
        common, ci = paired_delta(old, new)
        so, sn = summary(old), summary(new)
        out["cells"][name] = {"original": so, "repeat": sn, "common_items": len(common), "repeat_minus_original_ci": ci}
        f = lambda s: f"{s[0]} / {s[1]} / {s[2]} / {s[3]:.3f}"
        lines.append(f"| {name} | {f(so)} | {f(sn)} | {sn[3]-so[3]:+.3f} [{ci[0]:+.3f},{ci[1]:+.3f}] |")
    (ROOT / "P0_REPEAT_RESULTS.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    (ROOT / "P0_REPEAT_RESULTS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
