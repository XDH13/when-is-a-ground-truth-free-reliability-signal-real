"""Resume the user-paused independent-generation replication from 14B.

All collectors append only missing valid question records to their dedicated
repeat logs. Existing original, completed, and partial records are preserved.
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STATUS = ROOT / "P0_REPEAT_STATUS.json"
START = time.time()


def update(step, state, **extra):
    d = {"step": step, "state": state,
         "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
         "elapsed_hours": round((time.time() - START) / 3600, 3), **extra}
    t = STATUS.with_suffix(".json.tmp")
    t.write_text(json.dumps(d, indent=2), encoding="utf-8")
    os.replace(t, STATUS); print("STATUS", json.dumps(d), flush=True)


def run(step, script, env):
    update(step, "RUNNING", script=script)
    full = os.environ.copy(); full.update(env)
    code = subprocess.run([sys.executable, script], cwd=ROOT, env=full).returncode
    if code:
        update(step, "FAILED", returncode=code); raise SystemExit(code)
    update(step, "COMPLETE")


def main():
    update("resume_14b", "RUNNING", protocol="unseeded generation; fixed item-order seed only")
    run("math_qwen14", "exp4_collect.py", {"EXP0_MODEL": "qwen2.5:14b-instruct",
        "EXP4_LOG": "repeat_math_qwen14.jsonl", "EXP4_LIMIT": "240", "EXP0_SEED": "20260911"})
    for tag, model in [("qwen3", "qwen2.5:3b-instruct"), ("qwen7", "qwen2.5:7b-instruct"),
                       ("qwen14", "qwen2.5:14b-instruct"), ("llama8", "llama3.1:8b"),
                       ("mistral7", "mistral:7b-instruct")]:
        run(f"mmlu_{tag}", "p0_mcq_collect.py", {"EXP0_MODEL": model,
            "P0_MCQ_POOL": "mmlu_holdout_pool.json", "P0_MCQ_LOG": f"repeat_mmlu_{tag}.jsonl",
            "P0_MCQ_LIMIT": "200", "P0_DOMAIN": "mmlu-holdout",
            "P0_MCQ_SEED": "20260911", "P0_MCQ_MAX_TOKENS": "128"})
    run("analysis", "p0_repeat_analyze.py", {})
    update("all", "COMPLETE")


if __name__ == "__main__":
    main()
